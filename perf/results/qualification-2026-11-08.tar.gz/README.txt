Sanitized measurement evidence for the performance action plan, 2026-11-08.
Numeric observations and failures are retained. Private repository, fixture and
NAS locations are replaced with placeholders; synthetic review tokens are
redacted. No binaries, source corpus data, credentials or helper transcripts
are included. See ../qualification-results.md and index.csv for interpretation.
A zero process exit code is not a memory-budget or release-qualification pass.
Kernel peak RSS covers the whole process, not individual iterations, and excludes
SSH child/server processes. Raw ps CPU values are not per-phase CPU readings.
