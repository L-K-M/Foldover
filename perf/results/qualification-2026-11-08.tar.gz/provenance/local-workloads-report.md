# Local workloads qualification report

Bounded qualification run of the saved `build/performance-work/bin/qualification-counters`
binary (built from commit `292d24b`, SHA-256
`c86b2e53c8f1d6f2f3b69129aa394a6de7d6dd72c6b9ee07ed135d01eca4e2cb`) through
`perf/run-qualification.py`, on two newly generated local 10,000-file fixtures.
Exact setup/run script: `build/performance-work/local-workloads-script.py`
(run log: `build/performance-work/local-workloads-run.log`).

## Fixture root

Exact container root, also recorded in `build/performance-work/local-workloads-root.txt`:

```
$LOCAL_WORKLOADS
```

New, owned (mode 0700 at creation, now 0755 for inspection), created for this run
only; no other corpus was touched. The concurrent NAS benchmark stayed on the NAS:
every fixture byte stayed on local temp storage (`$TEMP`); only small
result artifacts were written under `build/performance-work/`. The fixture is left
in place for parent inspection, with source/target trees readable (dirs 0755,
files 0644); each catalog `state/` stays 0700.

| Variant | Files | File size | Subdirectories | Total file bytes | Layout |
| --- | ---: | ---: | ---: | ---: | --- |
| `flat-1kib` | 10,000 | 1 KiB | 0 | 10,240,000 | files directly in the flat source root |
| `deep-unicode-32kib` | 10,000 | 32 KiB | 4,254 | 327,680,000 | 8 Unicode directory components, 2,000 leaf dirs x 5 files |

Deep paths are 9 components long (8 directories plus the file name), e.g.
`ドキュメント/проекты/projets/α/2024年/nível/第七層/葉-甲/doc-00.bin`; branching
radices per level are `[2, 2, 2, 5, 5, 5, 1, 2]`.

Per-file bytes are deterministic and distinct: `SHAKE-256("foldover-perf-local-workloads/<variant>/<relpath>")`
truncated to the file size, with `:v1` (edit) and `:v2` (replace) suffixes for
mutations. Uniqueness was asserted during generation. Manifests with every
relative path, size and SHA-256 are in `<container>/<variant>/source-manifest.json`;
mutations are recorded in `<container>/<variant>/mutations.json`.

## Cases and raw results

Each fixture ran four complete single-iteration cases (`--iterations 1`,
`--revision 292d24b`) against one dedicated catalog (`<container>/<variant>/state`),
in this order: initial copy to an empty right; no-change; exactly 100 in-place
content edits (same paths, no rename); then 100 atomic replaces (temp file +
`os.replace`) of different files and 100 unlinks of a third, disjoint set of
files with every parent directory retained. Labels are honest about the shared
local host, e.g. `local-shared-host flat-1kib initial rev-292d24b`.

| Variant | Case | Result (copied/updated/archived) | Commits | Planned (changes, bytes) | Applied bytes | Total | Wall | Peak RSS |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| flat-1kib | initial | 10000 / 0 / 0 | 41 | 10000, 10,240,000 | 10,240,000 | 2.661 s | 2.747 s | 18.5 MiB |
| flat-1kib | nochange | 0 / 0 / 0 | 1 | 0, 0 | 0 | 0.926 s | 1.048 s | 18.2 MiB |
| flat-1kib | edit100 | 100 / 0 / 0 | 1 | 100, 102,400 | 102,400 | 0.441 s | 0.506 s | 20.2 MiB |
| flat-1kib | replace100-delete100 | 100 / 0 / 100 | 1 | 200, 102,400 | 102,400 | 0.227 s | 0.305 s | 19.1 MiB |
| deep-unicode-32kib | initial | 14254 / 0 / 0 | 57 | 14254, 327,680,000 | 327,680,000 | 16.605 s | 16.638 s | 22.2 MiB |
| deep-unicode-32kib | nochange | 0 / 0 / 0 | 1 | 0, 0 | 0 | 4.969 s | 5.007 s | 22.4 MiB |
| deep-unicode-32kib | edit100 | 100 / 0 / 0 | 1 | 100, 3,276,800 | 3,276,800 | 1.890 s | 1.922 s | 25.8 MiB |
| deep-unicode-32kib | replace100-delete100 | 100 / 0 / 100 | 1 | 200, 3,276,800 | 3,276,800 | 1.825 s | 1.850 s | 23.3 MiB |

All 8 runs exited 0 with no `error`, no `parsing_errors` and no `cleanup_errors`.
Every case directory under `build/performance-work/local-workloads/<variant>/<case>/`
retains `runner.tsv`, `resources.txt`, `summary.json`, `samples.jsonl`, the
wrapper command/stdout/stderr, and a `checks.json` with the full verification.

## Checks

- Raw counts vs expected file/directory operations: all 8 cases match exactly.
  Initial copy counts every created directory (`14,254 = 10,000 files + 4,254
  dirs` deep; `10,000 + 0` flat). Content edits and atomic replaces count as
  `copied` (`ReplaceContent`), deletions as `archived`; `PlannedLogicalBytes`
  and `AppliedLogicalBytes` count only copied file bytes, never deletion
  archives. After case 4 each source and target holds 9,900 files.
- Path sets and contents: after every successful run, the source and target
  relative file path sets are identical, every file's SHA-256 matches, and the
  directory sets match (4,254/4,254 deep, 0/0 flat). Engine-owned `.foldover`
  state (pair id, archive) is excluded from the fixture comparison.
- Archive spot checks: the 100 pre-edit originals, the 100 pre-replace
  originals and the 100 pre-delete files archived on the right match the
  recorded manifest/mutation hashes, and every deleted parent directory is
  retained.
- Note on archive volume: 300 files exist on disk under
  `<container>/<variant>/target/.foldover/archive/` (100 old versions from
  `edit100`, 100 old versions from `replace100`, 100 deleted files). The
  `archived` result counter reports only the 100 deletion-archives; content
  replacements archive the previous version without incrementing `archived`.

## Limitations

- Local shared host only: both roots are on the same Mac's local temp storage.
  This is not NAS, SSH or LAN qualification; no network latency, encryption or
  remote filesystem behavior is covered.
- One iteration per case, as specified; no warm-up pairing and no repeated
  samples, so the timings are single observations.
- The host was busy (load average about 9-14 during the runs, NAS benchmark
  active elsewhere); absolute times are not comparable with idle-host budgets.
- Fixture bytes are synthetic, deterministic, incompressible SHAKE output, not
  real documents; the deep tree is fixed at 8 directory levels with the
  branching above.
- `run-qualification.py` recorded benign `sampling_errors` (`ps exited 1`) in
  every `summary.json`: the per-line RSS sampler races the runner's exit. They
  are retained, and no parsing or cleanup errors occurred.
- Wall time includes the runner's once-per-second `ps` sampling overhead; the
  runner's own `Total` metric excludes it.
- No source or binary changes, no Cargo, no SSH, no other benchmarks, no
  helpers, no commit or push. The fixture was not removed.
- Worktree state: this script changed no tracked file. `git status` shows
  pre-existing uncommitted edits in `.gitignore`, `perf/sftp.md` and
  `perf/run-qualification.py` (mtimes before this run, plus one concurrent
  one-line error-message edit to `perf/run-qualification.py` at 05:57:32 during
  the run, not made by this script). That edit only affects a `ParseError`
  message string; all runs parsed cleanly and no malformed record occurred.
