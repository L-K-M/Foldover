#!/usr/bin/env python3
"""Exact setup and run script for the local-workloads qualification experiment.

Creates one new owned temporary container with prefix
``foldover-perf-local-workloads-`` on local temp storage, records its exact root
in ``build/performance-work/local-workloads-root.txt``, generates two
deterministic 10,000-file fixtures (1 KiB flat, 32 KiB deep Unicode), and runs
four complete single-iteration qualification cases per fixture against one
dedicated catalog each, using the saved
``build/performance-work/bin/qualification-counters`` binary (built from commit
292d24b) through ``perf/run-qualification.py``.

After every successful run the script checks the raw counter/result records
against the expected file/directory operations and compares the source and
target file path sets and contents. Failures are retained, never hidden.

The script never touches another corpus, never removes the fixture, and leaves
the source/target trees readable for parent inspection. The concurrent NAS
benchmark means every fixture byte stays on local temp storage. See
``build/performance-work/local-workloads-report.md``.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time

REVISION = "292d24b"
CONTAINER_PREFIX = "foldover-perf-local-workloads-"
FILE_COUNT = 10_000
MUTATION_COUNT = 100

WORK = Path(__file__).resolve().parents[2]
RUNNER = WORK / "build/performance-work/bin/qualification-counters"
RUNNER_SCRIPT = WORK / "perf/run-qualification.py"
OUT_ROOT = WORK / "build/performance-work/local-workloads"
ROOT_FILE = WORK / "build/performance-work/local-workloads-root.txt"
SUMMARY_FILE = WORK / "build/performance-work/local-workloads-summary.json"

FLAT_SIZE = 1024
DEEP_SIZE = 32768
DEEP_RADICES = [2, 2, 2, 5, 5, 5, 1, 2]
DEEP_NAMES = [
    ["ドキュメント", "文档"],
    ["проекты", "프로젝트"],
    ["projets", "प्रोजेक्ट"],
    ["α", "β", "γ", "δ", "ε"],
    ["2024年", "2025年", "2026年", "2027年", "2028年"],
    ["nível", "级别", "στάδιο", "स्तर", "수준"],
    ["第七層"],
    ["葉-甲", "葉-乙"],
]
DEEP_FILES_PER_LEAF = FILE_COUNT // (2 * 2 * 2 * 5 * 5 * 5 * 1 * 2)

CASES = ["initial", "nochange", "edit100", "replace100-delete100"]


def flat_relpath(index: int) -> Path:
    return Path(f"document-{index:06d}.bin")


def deep_relpath(index: int) -> Path:
    leaf, within = divmod(index, DEEP_FILES_PER_LEAF)
    digits = []
    remaining = leaf
    for radix in reversed(DEEP_RADICES):
        digits.append(remaining % radix)
        remaining //= radix
    digits.reverse()
    parts = [DEEP_NAMES[level][digits[level]] for level in range(len(DEEP_RADICES))]
    return Path(*parts) / f"doc-{within:02d}.bin"


def file_bytes(seed: str, size: int, version: int = 0) -> bytes:
    payload = seed.encode()
    if version:
        payload += f":v{version}".encode()
    return hashlib.shake_256(payload).digest(size)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def generate_source(source: Path, relpath_of, size: int, seed: str) -> dict:
    """Write the deterministic fixture and return its manifest."""
    manifest = {}
    seen = set()
    for index in range(FILE_COUNT):
        rel = relpath_of(index)
        path = source / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        data = file_bytes(f"{seed}/{rel}", size)
        digest = sha256_bytes(data)
        if digest in seen:
            raise SystemExit(f"duplicate deterministic content at {rel}")
        seen.add(digest)
        with path.open("xb") as stream:
            stream.write(data)
        os.chmod(path, 0o644)
        manifest[str(rel)] = {"bytes": size, "sha256": digest}
    for dirpath, _dirnames, _filenames in os.walk(source):
        os.chmod(dirpath, 0o755)
    os.chmod(source, 0o755)
    return manifest


def apply_edits(source: Path, relpath_of, size: int, seed: str, indices: list) -> dict:
    """Rewrite exactly the named files in place, same path, no rename."""
    changed = {}
    for index in indices:
        rel = relpath_of(index)
        path = source / rel
        before = sha256_bytes(path.read_bytes())
        data = file_bytes(f"{seed}/{rel}", size, version=1)
        with path.open("wb") as stream:
            stream.write(data)
        os.chmod(path, 0o644)
        changed[str(rel)] = {"before": before, "after": sha256_bytes(data),
                             "mode": "in-place rewrite, same path"}
    return changed


def apply_replaces(source: Path, relpath_of, size: int, seed: str, indices: list) -> dict:
    """Atomically replace exactly the named files (temp file + rename)."""
    changed = {}
    for index in indices:
        rel = relpath_of(index)
        path = source / rel
        before = sha256_bytes(path.read_bytes())
        data = file_bytes(f"{seed}/{rel}", size, version=2)
        temp = path.parent / f".atomic-{path.name}.{os.getpid()}.tmp"
        with temp.open("xb") as stream:
            stream.write(data)
        os.chmod(temp, 0o644)
        os.replace(temp, path)
        changed[str(rel)] = {"before": before, "after": sha256_bytes(data),
                             "mode": "atomic replace (temp + rename)"}
    return changed


def apply_deletes(source: Path, relpath_of, indices: list) -> dict:
    """Delete exactly the named files; every parent directory is retained."""
    removed = {}
    for index in indices:
        rel = relpath_of(index)
        path = source / rel
        removed[str(rel)] = {"sha256": sha256_bytes(path.read_bytes()),
                             "mode": "unlink; parent directory retained"}
        path.unlink()
    return removed


def run_case(variant: str, case: str, source: Path, target: Path, state: Path,
             label: str) -> dict:
    """Run one complete single-iteration case and retain every raw artifact."""
    output = OUT_ROOT / variant / case
    command = [sys.executable, str(RUNNER_SCRIPT),
               "--runner", str(RUNNER),
               "--state", str(state),
               "--left", str(source),
               "--right", str(target),
               "--iterations", "1",
               "--output", str(output),
               "--label", label,
               "--revision", REVISION]
    started = time.time()
    proc = subprocess.run(command, capture_output=True, text=True)
    elapsed = time.time() - started
    output.mkdir(parents=True, exist_ok=True)
    (output / "wrapper.stdout.txt").write_text(proc.stdout)
    (output / "wrapper.stderr.txt").write_text(proc.stderr)
    (output / "wrapper.command.json").write_text(json.dumps(
        {"command": command, "returncode": proc.returncode,
         "elapsed_seconds": elapsed}, indent=2) + "\n")
    return {"output": output, "command": command, "returncode": proc.returncode,
            "elapsed_seconds": elapsed}


def parse_runner_tsv(path: Path) -> dict:
    counters, planned, result, metrics = {}, None, None, {}
    for line in path.read_text().splitlines():
        fields = line.split("\t")
        if fields[0] == "counter":
            counters[fields[2]] = int(fields[3])
        elif fields[0] == "planned":
            planned = {"changes": int(fields[2]), "bytes": int(fields[3])}
        elif fields[0] == "result":
            result = {"copied": int(fields[2]), "updated": int(fields[3]),
                      "archived": int(fields[4]), "commits": int(fields[5])}
        elif fields[0] == "metric" and fields[2] == "Total":
            metrics["total_ns"] = int(fields[3])
    return {"counters": counters, "planned": planned, "result": result,
            "metrics": metrics}


def scan_tree(root: Path) -> tuple:
    """Return ({relative file path: sha256}, {relative directory path})."""
    files, dirs = {}, set()
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name != ".foldover"]
        rel = Path(dirpath).relative_to(root)
        if str(rel) != ".":
            dirs.add(str(rel))
        for name in filenames:
            path = Path(dirpath) / name
            files[str(path.relative_to(root))] = sha256_bytes(path.read_bytes())
    return files, dirs


def expected_counts(case: str, file_count: int, dir_count: int, size: int) -> dict:
    if case == "initial":
        return {"PlannedChanges": file_count + dir_count,
                "PlannedLogicalBytes": file_count * size,
                "AppliedLogicalBytes": file_count * size,
                "copied": file_count + dir_count, "updated": 0, "archived": 0}
    if case == "nochange":
        return {"PlannedChanges": 0, "PlannedLogicalBytes": 0,
                "AppliedLogicalBytes": 0, "copied": 0, "updated": 0, "archived": 0}
    if case == "edit100":
        return {"PlannedChanges": MUTATION_COUNT,
                "PlannedLogicalBytes": MUTATION_COUNT * size,
                "AppliedLogicalBytes": MUTATION_COUNT * size,
                "copied": MUTATION_COUNT, "updated": 0, "archived": 0}
    if case == "replace100-delete100":
        return {"PlannedChanges": 2 * MUTATION_COUNT,
                "PlannedLogicalBytes": MUTATION_COUNT * size,
                "AppliedLogicalBytes": MUTATION_COUNT * size,
                "copied": MUTATION_COUNT, "updated": 0, "archived": MUTATION_COUNT}
    raise ValueError(case)


def verify_case(case: str, run: dict, source: Path, target: Path,
                file_count: int, dir_count: int, size: int) -> dict:
    """Check one finished case: raw counts, then path sets and contents."""
    output = run["output"]
    check = {"case": case, "output_dir": str(output),
             "returncode": run["returncode"], "elapsed_seconds": run["elapsed_seconds"],
             "counts": None, "filesystem": None}
    summary_path = output / "summary.json"
    summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
    check["summary_error"] = summary.get("error")
    check["parsing_errors"] = summary.get("parsing_errors", [])
    check["cleanup_errors"] = summary.get("cleanup_errors", [])
    tsv_path = output / "runner.tsv"
    parsed = parse_runner_tsv(tsv_path) if tsv_path.exists() else \
        {"counters": {}, "planned": None, "result": None, "metrics": {}}
    check["raw"] = parsed
    expected = expected_counts(case, file_count, dir_count, size)
    check["expected"] = expected
    actual = dict(parsed["counters"])
    actual.update(parsed["result"] or {})
    check["counts_match"] = all(actual.get(key) == value for key, value in expected.items())
    check["counts_actual"] = actual
    if run["returncode"] == 0 and not summary.get("error"):
        source_files, source_dirs = scan_tree(source)
        target_files, target_dirs = scan_tree(target)
        check["filesystem"] = {
            "source_files": len(source_files), "target_files": len(target_files),
            "source_dirs": len(source_dirs), "target_dirs": len(target_dirs),
            "path_sets_match": set(source_files) == set(target_files),
            "content_hashes_match": source_files == target_files,
            "directory_sets_match": source_dirs == target_dirs,
        }
    return check


def make_readable(root: Path) -> None:
    """Leave the fixture trees usable for parent inspection (never .foldover)."""
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name != ".foldover"]
        os.chmod(dirpath, 0o755)
        for name in filenames:
            os.chmod(Path(dirpath) / name, 0o644)
    os.chmod(root, 0o755)


def main() -> None:
    if not RUNNER.exists() or not RUNNER_SCRIPT.exists():
        raise SystemExit("saved runner binary or perf/run-qualification.py is missing")
    if ROOT_FILE.exists() or OUT_ROOT.exists():
        raise SystemExit("local-workloads artifacts already exist; refusing to overwrite")

    container = Path(tempfile.mkdtemp(prefix=CONTAINER_PREFIX,
                                      dir=tempfile.gettempdir()))
    os.chmod(container, 0o700)
    ROOT_FILE.write_text(str(container) + "\n")

    variants = {
        "flat-1kib": {"size": FLAT_SIZE, "relpath_of": flat_relpath,
                      "seed": "foldover-perf-local-workloads/flat-1kib",
                      "delete_indices": list(range(200, 300))},
        "deep-unicode-32kib": {"size": DEEP_SIZE, "relpath_of": deep_relpath,
                               "seed": "foldover-perf-local-workloads/deep-unicode-32kib",
                               "delete_indices": [leaf * DEEP_FILES_PER_LEAF
                                                  for leaf in range(40, 140)]},
    }
    edit_indices = list(range(0, MUTATION_COUNT))
    replace_indices = list(range(MUTATION_COUNT, 2 * MUTATION_COUNT))

    setup = {"container": str(container), "revision": REVISION,
             "runner": str(RUNNER),
             "runner_sha256": sha256_bytes(RUNNER.read_bytes()),
             "host": platform.platform(), "python": platform.python_version(),
             "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
             "variants": {}, "checks": []}
    print(f"container: {container}", flush=True)

    for variant, spec in variants.items():
        variant_dir = container / variant
        variant_dir.mkdir(mode=0o755)
        os.chmod(variant_dir, 0o755)
        source = variant_dir / "source"
        target = variant_dir / "target"
        state = variant_dir / "state"
        source.mkdir(mode=0o755)
        target.mkdir(mode=0o755)
        os.chmod(source, 0o755)
        os.chmod(target, 0o755)
        state.mkdir(mode=0o700)
        os.chmod(state, 0o700)

        manifest = generate_source(source, spec["relpath_of"], spec["size"], spec["seed"])
        _source_files, source_dirs = scan_tree(source)
        file_count = len(manifest)
        dir_count = len(source_dirs)
        (variant_dir / "source-manifest.json").write_text(json.dumps(manifest, indent=1) + "\n")
        setup["variants"][variant] = {
            "source": str(source), "target": str(target), "state": str(state),
            "size": spec["size"], "files": file_count, "dirs": dir_count,
            "delete_indices": spec["delete_indices"],
        }
        print(f"{variant}: {file_count} files, {dir_count} dirs, "
              f"{file_count * spec['size']} bytes", flush=True)

        mutations = {}
        for case in CASES:
            if case == "edit100":
                mutations["edit100"] = apply_edits(source, spec["relpath_of"],
                                                   spec["size"], spec["seed"],
                                                   edit_indices)
            elif case == "replace100-delete100":
                mutations["replace100-delete100"] = {
                    "replaced": apply_replaces(source, spec["relpath_of"],
                                               spec["size"], spec["seed"],
                                               replace_indices),
                    "deleted": apply_deletes(source, spec["relpath_of"],
                                             spec["delete_indices"]),
                }
                (variant_dir / "mutations.json").write_text(json.dumps(mutations, indent=1) + "\n")
            label = f"local-shared-host {variant} {case} rev-{REVISION}"
            run = run_case(variant, case, source, target, state, label)
            check = verify_case(case, run, source, target, file_count, dir_count,
                                spec["size"])
            (run["output"] / "checks.json").write_text(json.dumps(check, indent=2) + "\n")
            setup["checks"].append({"variant": variant, **check})
            verdict = "ok" if (check["counts_match"] and
                               check["filesystem"] and
                               check["filesystem"]["path_sets_match"] and
                               check["filesystem"]["content_hashes_match"] and
                               check["filesystem"]["directory_sets_match"]) else "FAIL"
            raw = check["raw"]
            print(f"  {case}: rc={run['returncode']} planned={raw['planned']} "
                  f"counters={raw['counters']} result={raw['result']} "
                  f"counts_match={check['counts_match']} fs={check['filesystem']} "
                  f"-> {verdict}", flush=True)

        make_readable(source)
        make_readable(target)

    setup["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    SUMMARY_FILE.write_text(json.dumps(setup, indent=2) + "\n")
    failures = [entry for entry in setup["checks"]
                if not entry["counts_match"] or not entry["filesystem"] or
                not entry["filesystem"]["path_sets_match"] or
                not entry["filesystem"]["content_hashes_match"] or
                not entry["filesystem"]["directory_sets_match"]]
    print(f"finished; {len(setup['checks'])} cases, {len(failures)} failing", flush=True)
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
