import csv, gzip, hashlib, io, json, pathlib, re, subprocess, tarfile

repo=pathlib.Path.cwd(); work=repo/'build/performance-work'; output=repo/'perf/results'; output.mkdir(exist_ok=True)
local=(work/'lan-local.txt').read_text().strip(); remote=(work/'lan-root.txt').read_text().strip()
profile=(work/'profile-results-kept/fixture-root.txt').read_text().strip()
replacements=[(str(repo),'$REPO'),(local,'$LOCAL_FIXTURE'),(local.replace('/var/','/private/var/',1),'$LOCAL_FIXTURE'),(remote,'$NAS_FIXTURE'),(profile,'$PROFILE_FIXTURE'),('benchmark@nas.invalid','benchmark@nas.invalid'),('nas.invalid','nas.invalid'),('benchmark','benchmark')]
counter_root=(work/'counter-fixture-root.txt').read_text().strip()
replacements.extend([(counter_root,'$COUNTER_FIXTURE'),(counter_root.replace('/var/','/private/var/',1),'$COUNTER_FIXTURE')])
local_workloads=(work/'local-workloads-root.txt').read_text().strip()
replacements.extend([(local_workloads,'$LOCAL_WORKLOADS'),(local_workloads.replace('/var/','/private/var/',1),'$LOCAL_WORKLOADS'),('$TEMP','$TEMP')])
if (work/'agent-persistent-root.txt').exists():
 agent_root=(work/'agent-persistent-root.txt').read_text().strip()
 replacements.extend([(agent_root,'$AGENT_FIXTURE'),(str(pathlib.Path(agent_root).resolve()),'$AGENT_FIXTURE')])
if (work/'agent-ipc-runtime-roots.json').exists():
 for index,runtime in enumerate(json.loads((work/'agent-ipc-runtime-roots.json').read_text())):
  replacements.extend([(runtime,f'$AGENT_RUNTIME_{index}'),(str(pathlib.Path(runtime).resolve()),f'$AGENT_RUNTIME_{index}')])
replacements.append((str(repo.resolve()),'$REPO'))
replacements.sort(key=lambda x:len(x[0]),reverse=True)
def sanitize(text):
 for source,target in replacements:text=text.replace(source,target)
 return re.sub(r'("review_token"\s*:\s*")[0-9a-f]+(")',r'\1<synthetic-token-redacted>\2',text)

def source_base_commit(label):
 # Labels may describe patches as well as their base; never imply that a
 # resolved base commit identifies the entire patched source tree.
 match=re.match(r'^([0-9a-f]{7,40})(?:$|[\s+])',label or '')
 revision=match[1] if match else label if re.fullmatch(r'.+-[0-9]+-g[0-9a-f]{7,40}',label or '') else None
 if not revision:return None
 result=subprocess.run(['git','rev-parse','--verify',revision+'^{commit}'],text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 commit=result.stdout.strip()
 return commit if result.returncode==0 and re.fullmatch(r'[0-9a-f]{40}',commit) else None

names=['threads1k-paired','threads10k-paired','batch10k-paired','finish1k-paired','finish10k-paired','lan10k-paired','local-readers-paired','archive-paired','lan100k-pinned-dense','lan100k-paired','lan1m-baseline-prepare','local1m-owned-raw','local1m-shared-preview','local1m-compact-firstcopy','local1m-streamed','local1m-integration-prepare','native1m-seed','native1m-warm-before','native1m-expired-before','native1m-expired-after','native1m-expired-packed','native1m-initial-hints','state1m-input-memory','state1m-exact-fingerprint-memory','state1m-canonical-input-memory','state1m-native-input-memory','state1m-native-compact-input-memory','state1m-sftp-compact-input-memory','service1m-expired','service1m-tight','service1m-union','service1m-input-lock','service1m-scan-cancellation','logical-byte-counters','local-workloads','lan1m-final','ssh-packet-pairs','lan-reverse10k-final','lan-largefile-final']
names.extend(p.name for p in work.iterdir() if p.is_dir() and p.name.startswith('lan100k-') and (p/'summary.json').exists())
names.extend(['lan1m-client-debug','agent1m-ipc-preview','agent1m-persistent-seed','agent1m-ipc-persistent','agent1m-ipc-early-comparison'])
# Publish this final comparison only after its supervising process has stopped.
paired_status=work/'lan100k-retry-final-status.json'
if paired_status.exists():
 final=json.loads(paired_status.read_text())
 assert final['collection_finished'] is True
 actual=sorted(str(p.parent.relative_to(work/'lan100k-retry-paired')) for p in (work/'lan100k-retry-paired').rglob('summary.json'))
 assert actual==sorted(final['completed_cases']), 'final comparison case set changed'
 names.append('lan100k-retry-paired')
files={}; rows=[]; sources={}
for name in sorted(set(names)):
 root=work/name
 if not root.exists():raise RuntimeError(f'missing selected result {name}')
 summaries=sorted(root.rglob('summary.json'))
 if not summaries:raise RuntimeError(f'no completed summary in {name}')
 for summary in summaries:
  case=str(summary.parent.relative_to(work)); sources[case]=summary.parent
for summary in sorted((work/'profile-results-kept/runs').rglob('summary.json')):
 sources['profile/'+str(summary.parent.relative_to(work/'profile-results-kept/runs'))]=summary.parent

for case,root in sorted(sources.items()):
 s=json.loads((root/'summary.json').read_text()); resource=(root/'resources.txt').read_text()
 rss=re.search(r'^\s*(\d+)\s+maximum resident set size',resource,re.M); rss=int(rss[1]) if rss else None
 metrics=s.get('measurements',[]); iterations=sorted({m.get('iteration',0) for m in metrics}) or [0]
 for i in iterations:
  phase={m['phase']:m['ns'] for m in metrics if m.get('iteration',0)==i and 'ns' in m}
  counters={m['phase']:m['value'] for m in metrics if m.get('iteration',0)==i and m.get('event')=='counter'}
  row={'case':case,'iteration':i,'returncode':s.get('returncode'),'source_label':s.get('revision'),'source_base_commit':source_base_commit(s.get('revision')),'binary_sha256':s.get('binary_sha256'),'kernel_peak_rss_bytes':rss,'rss_below_500mb':rss<500_000_000 if rss is not None else None,'harness_elapsed_s':s.get('elapsed_seconds'),'max_ssh_children':s.get('sampled_peak_ssh_children'),'sampling_errors':len(s.get('sampling_errors',[])),'parsing_errors':len(s.get('parsing_errors',[]))}
  for field,p in [('total_s','Total'),('observe_left_s','ObserveLeft'),('observe_right_s','ObserveRight'),('apply_s','Apply'),('input_decode_s','InputDecode'),('service_preview_s','ServicePreview'),('max_status_ns','MaximumStatusLatency'),('max_poll_delay_ns','MaximumPollDelay'),('input_lock_capture_s','InputLockCapture'),('contending_engine_lock_wait_s','ContendingEngineLockWait'),('scan_cancellation_s','ScanCancellation'),('agent_preview_ipc_s','AgentPreviewIPC'),('max_status_with_client_start_s','MaximumStatusRoundTripIncludingClientStart')]:
   row[field]=phase.get(p) if field.endswith('_ns') else phase.get(p)/1e9 if p in phase else None
  row.update(probe_rounds=counters.get('ProbeRounds'),read_requests=counters.get('ReadRequests'),data_payload_bytes=counters.get('DataPayloadBytes'),peak_outstanding_requests=counters.get('PeakOutstandingRequests'),planned_logical_bytes=counters.get('PlannedLogicalBytes'),applied_logical_bytes=counters.get('AppliedLogicalBytes'),copied=None,updated=None,archived=None,commits=None)
  for line in (root/'runner.tsv').read_text().splitlines():
   parts=line.split('\t')
   if len(parts)==6 and parts[0]=='result' and parts[1]==str(i):
    row.update(zip(['copied','updated','archived','commits'],map(int,parts[2:])))
  rows.append(row)
 for name in ['summary.json','resources.txt','runner.tsv','samples.jsonl','checks.json','probe.csv','events.jsonl']:
  p=root/name
  if p.exists():files[f'cases/{case}/{name}']=sanitize(p.read_text()).encode()

for p in sorted(work.glob('*provenance*.json')):
 files['provenance/'+p.name]=sanitize(p.read_text()).encode()
for name in ['timestamp-source.patch','timestamp-packed-source.patch','ssh-debug-source.patch','agent-ipc-source.patch','agent-early-comparison-source.patch','agent-early-comparison-core.patch','timestamp-source.sha256','fingerprint-zero-profile.json','fingerprint-delta-profile.json','archive-paired/provenance.json','lan100k-retry-paired/provenance.json','lan100k-retry-final-status.json']:
 p=work/name
 if p.exists():files['provenance/'+name.replace('/','-')]=sanitize(p.read_text()).encode()
for name in ['archive-overlap-before.log','archive-overlap-fixed.log','refresh-overwrite-false-negative-before.log','refresh-overwrite-fixed.log','plan-capacity-before.log','plan-capacity-fixed.log','plan-mixed-capacity-before.log','plan-union-capacity-fixed.log','counter-before.log','counter-python-tests.log']:
 p=work/name
 if p.exists():files['regressions/'+name]=sanitize(p.read_text()).encode()
for name in ['final-bench-check.log','plan-reserved-bench-check.log','plan-union-bench-check.log','qualification-complete-bench-check.log']:
 p=work/name
 if p.exists():
  text=p.read_text(); marker=re.search(r'^benchmark\s+median\s+budget\s+status$',text,re.M)
  if not marker:raise RuntimeError(f'missing benchmark gate table in {name}')
  files['checks/'+name.replace('.log','.txt')]=sanitize(text[marker.start():]).encode()

for p in sorted((work/'path-scaling-results').rglob('*.json')):
 files['checks/path-scaling/'+str(p.relative_to(work/'path-scaling-results'))]=sanitize(p.read_text()).encode()
for name in ['run-service-diagnostics.py','run-ssh-packet-pairs.py','run-lan-extended.py','local-workloads-script.py','local-workloads-summary.json','local-workloads-report.md','path-qualification-report.md','restore-agent-corpus.py','prepare-agent-ipc-fixture.py','verify-agent-ipc-fixture.py','run-agent-ipc-qualification.py','agent-probe-selection.json','run-100k-retry-pairs.py','summarize-final-100k.py','state-load.rs','run-service-memory.py','legacy-source-gaps.json','package-results.py']:
 p=work/name
 if p.exists():files['provenance/'+name]=sanitize(p.read_text()).encode()

builds=[]
for profile_name,wall,crates in [('default',7.87,12),('thin',36.55,163)]:
 binaries=[p for p in (work/'profile-results-kept/bin'/profile_name).rglob('*') if p.is_file() and p.stat().st_size>1_000_000]
 assert len(binaries)==1
 binary=binaries[0]
 builds.append({'profile':profile_name,'wall_seconds':wall,'compiled_crates':crates,'binary_bytes':binary.stat().st_size,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'lto':'thin' if profile_name=='thin' else 'workspace default','codegen_units':1 if profile_name=='thin' else 'workspace default','cache_state':'all dependencies rebuilt' if profile_name=='thin' else 'registry dependencies reused; own crates rebuilt'})
files['provenance/profile-builds.json']=(json.dumps({'note':'Different build-cache states. These timings do not establish a clean-build cost ratio. No FFI/profile promotion claim.','builds':builds},indent=2)+'\n').encode()
for p in sorted((work/'service-union-source').rglob('*.rs')):
 files['provenance/service-union-source/'+str(p.relative_to(work/'service-union-source'))]=sanitize(p.read_text()).encode()
files['provenance/LICENSE']= (repo/'LICENSE').read_bytes()
files['README.txt']=b'''Sanitized measurement evidence for the performance action plan, 2026-11-08.\nNumeric observations and failures are retained. Private repository, fixture and\nNAS locations are replaced with placeholders; synthetic review tokens are\nredacted. No binaries, source corpus data, credentials or helper transcripts\nare included. See ../qualification-results.md and index.csv for interpretation.\nA zero process exit code is not a memory-budget or release-qualification pass.\nKernel peak RSS covers the whole process, not individual iterations, and excludes\nSSH child/server processes. Raw ps CPU values are not per-phase CPU readings.\n'''
archive=output/'qualification-2026-11-08.tar.gz'
with archive.open('wb') as stream:
 with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for name,data in sorted(files.items()):
    item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o600;item.mtime=0;tar.addfile(item,io.BytesIO(data))
index=output/'index.csv'
with index.open('w',newline='') as stream:
 writer=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
manifest={'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'index_sha256':hashlib.sha256(index.read_bytes()).hexdigest(),'index_schema_version':2,'case_count':len(sources),'iteration_rows':len(rows),'files':{name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}}
(output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('packaged',len(sources),'cases,',len(files),'files,',archive.stat().st_size,'compressed bytes')
