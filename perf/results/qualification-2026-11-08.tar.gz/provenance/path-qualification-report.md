# Path qualification report: million-query PathPrefixIndex benches

## Scope

Add the missing A5 scaling qualification for `PathPrefixIndex`: a
standalone `foldover-engine` Criterion bench with two variants, each
running 1,000,000 queries against 10,000 roots. Half the queries are
descendants that must match; half are boundary siblings that must not.
The exact expected hit count is asserted before timing. No planning or
index implementation was changed.

## Checkout and environment

- Checkout: `$REPO/build/performance-work/path-qualification`
- Branch: `perf/million-path-qualification`
- Commit: `62ba97c128853bb52847ccc36c05b8c01eddfbd5`
- Host: macOS 27.0.1 (26A434), Apple M4 Max, 36 GiB, Darwin 27.0.0
- Toolchain: rustc 1.99.0 (b940084d7 2026-09-28), cargo 1.99.0
- `CARGO_TARGET_DIR` (inherited, used for every command):
  `$REPO/build/cargo-path-qualification`
- Load averages during the run: 28.04, 25.04, 19.13. A separate NAS
  benchmark was active on the host.

## Changes

- `crates/foldover-engine/benches/path_prefix_index.rs` (new):
  standalone Criterion target `path_prefix_index` with
  `prefix_index_shallow_unicode_1m_queries_10k_roots` and
  `prefix_index_deep_unicode_1m_queries_10k_roots`. Both variants use
  10,000 roots and 1,000,000 queries; even queries are descendants,
  odd queries are boundary siblings that share leading bytes with a
  root component but diverge before a `/`. Criterion config:
  10 samples, 1 s warm-up, 3 s measurement. Setup builds roots, the
  index and queries outside the measured loop.
- `crates/foldover-engine/Cargo.toml`: registered the
  `path_prefix_index` bench target.
- `xtask/src/bench.rs`: added `("foldover-engine", "path_prefix_index")`
  to the `bench-check` target list.
- `perf/budgets.toml`: added the two new budget entries. Existing
  budgets are unchanged.
- `perf/README.md`: added the two new table rows.

## Exact commands

```sh
cd $REPO/build/performance-work/path-qualification

cargo fmt --all
cargo fmt --all --check

cargo clippy --locked --all-targets -p foldover-engine -p xtask -- -D warnings

cargo bench --locked -p foldover-engine --bench path_prefix_index -- \
  --warm-up-time 1 --measurement-time 3
```

Medians were read from
`$CARGO_TARGET_DIR/criterion/<id>/new/estimates.json` with:

```sh
python3 - <<'EOF'
import json, math
base = "$REPO/build/cargo-path-qualification/criterion"
for bench in ["prefix_index_shallow_unicode_1m_queries_10k_roots",
              "prefix_index_deep_unicode_1m_queries_10k_roots"]:
    with open(f"{base}/{bench}/new/estimates.json") as f:
        d = json.load(f)
    med_ms = d["median"]["point_estimate"] / 1e6
    print(f"{bench}: median {med_ms:.3f} ms; 3x = {med_ms * 3:.3f} ms; "
          f"ceil = {math.ceil(med_ms * 3)} ms")
EOF
```

## Results

| Criterion id | Median | 95% CI | 3x median | Budget |
|---|---|---|---|---|
| `prefix_index_shallow_unicode_1m_queries_10k_roots` | 122.944 ms | 122.561–125.066 ms | 368.832 ms | 369 ms |
| `prefix_index_deep_unicode_1m_queries_10k_roots` | 382.090 ms | 379.615–386.245 ms | 1146.271 ms | 1147 ms |

Console output from the bench run:

- Shallow: `time: [122.62 ms 123.69 ms 124.88 ms]`, 10 samples,
  30 iterations, 1 high mild outlier.
- Deep: `time: [380.67 ms 383.00 ms 385.54 ms]`, 10 samples,
  10 iterations. Criterion warned that it could not complete 10 samples
  in 3.0 s and extended to an estimated 3.85 s.

Both variants passed the pre-timing assertions:
`index.len() == 10_000`, `queries.len() == 1_000_000`, and
`count_hits == 500_000` (half descendants hit, half boundary siblings
miss).

`perf/budgets.toml` now has 19 entries; the two new values are 369 and
1147, each the measured median times three rounded up.

## Checks

- `cargo fmt --all --check`: passed.
- `cargo clippy --locked --all-targets -p foldover-engine -p xtask -- -D warnings`:
  passed.
- Bench assertions (exact hits, index and query counts): passed for both
  variants.
- Budgets parse as TOML and the two new ids match the criterion ids.

No other benchmarks were run. No SSH, corpus generators, desktop or GUI
tools, helpers, or helper JSONL transcripts were used.

## Limitations

- The host was shared with an active separate NAS benchmark; load
  averages were 19–28 during the run. The medians are wall-clock under
  uncontrolled load, not idle-host numbers. The 3x headroom is intended
  for CI runners.
- The deep variant needed about 3.85 s to collect 10 samples under the
  3 s measurement window. Criterion extended the window to finish the
  sample count; the budget absorbs the longer collection.
- Only `contains_ancestor` is timed. `contains` (one extra exact lookup)
  and dynamic `insert` growth are not budgeted.
- Setup is outside the measured loop: root construction, 1,000,000
  `SyncPath` allocations and `PathPrefixIndex::from_paths` are not
  covered by the budgets.
- The variants use UTF-8 Unicode names. Non-UTF8 raw bytes are covered
  by the existing `PathPrefixIndex` unit tests, not by these benches.
- Allocation counts were not measured. This task adds scaling timing
  qualification only.
- The bench is single-threaded and does not measure concurrency, cache
  contention or endpoint integration.
- This report is in `build/`, which is gitignored, so it is not part of
  the commit.
