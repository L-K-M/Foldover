#!/usr/bin/env python3
"""Prepare ONE isolated closed-catalog fixture for the agent IPC million-file preview.

The owned fixture root is read from ``lan-local.txt`` next to this script.  The
source catalog is ``<root>/native1m-aged/service-union``; the destination is the
new ``<root>/native1m-aged/agent-ipc``.  The source is cloned with ``cp -cR``
and never modified.  Only the snapshot fingerprint observation seconds are aged
by 21 days; every other fingerprint byte, every version, base row and
configuration value is preserved.  Before/after ordered digests and row counts
are written to ``agent-ipc-fixture-provenance.json``; the chosen pair id and
state path are written to ``agent-ipc-fixture.json``.

The destination must not exist.  The source catalog must be closed (no
non-empty WAL), must hold exactly one LOCAL/local pair whose roots are the
owned ``native1m-aged/source`` and ``native1m-aged/right`` endpoints, must have
schedule ``manual``, and must hold at least one million snapshot rows per side.
If any of that differs the script reports and stops without altering anything.

Streaming batches are used throughout; no million-row ``fetchall`` is performed.
The destination keeps normal WAL/FULL mode and is checkpointed and closed
before the script finishes.
"""

from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import time
import urllib.parse

DAYS = 21
SECONDS_PER_DAY = 24 * 60 * 60
DELTA_SECONDS = DAYS * SECONDS_PER_DAY
FINGERPRINT_HEADER_BYTES = 8 + 4 + 8
BATCH_ROWS = 5000
MIN_SNAPSHOT_ROWS_PER_SIDE = 1_000_000
DIGEST_DOMAIN = b"foldover-agent-ipc-fixture-v1"


class FixtureError(RuntimeError):
    """The source shape differs or a required invariant does not hold."""


def log(message: str) -> None:
    print(message, flush=True)


def fail(message: str) -> "NoReturn":  # type: ignore[name-defined]
    raise FixtureError(message)


def utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def connect_readonly(path: str) -> sqlite3.Connection:
    uri = "file:" + urllib.parse.quote(path) + "?mode=ro&immutable=1"
    return sqlite3.connect(uri, uri=True)


def connect_readwrite(path: str) -> sqlite3.Connection:
    return sqlite3.connect(path, isolation_level=None)


def database_journal_version(path: str) -> int:
    """Return the SQLite header read version: 2 means persistent WAL mode."""
    with open(path, "rb") as handle:
        header = handle.read(20)
    if len(header) < 20 or header[:16] != b"SQLite format 3\x00":
        fail(f"not a SQLite database: {path}")
    return header[18]


def owned_root(script_dir: str) -> str:
    marker = os.path.join(script_dir, "lan-local.txt")
    with open(marker, "rb") as handle:
        root = handle.read().strip().decode("utf-8")
    if not root or not os.path.isabs(root) or not os.path.isdir(root):
        fail(f"owned fixture root from {marker} is not an absolute directory: {root!r}")
    return root


def feed(digest: "hashlib._Hash", *parts: object) -> None:
    for part in parts:
        if part is None:
            digest.update(b"\x00")
        elif isinstance(part, int):
            digest.update(b"i" + str(part).encode("ascii") + b"\x00")
        elif isinstance(part, str):
            raw = part.encode("utf-8")
            digest.update(b"s" + len(raw).to_bytes(8, "little") + raw)
        elif isinstance(part, (bytes, bytearray, memoryview)):
            raw = bytes(part)
            digest.update(b"b" + len(raw).to_bytes(8, "little") + raw)
        else:
            raise TypeError(f"cannot digest {type(part)!r}")


def table_names(connection: sqlite3.Connection) -> list[str]:
    rows = connection.execute(
        "SELECT name FROM sqlite_master WHERE type = 'table' "
        "AND name NOT LIKE 'sqlite_%' ORDER BY name"
    ).fetchall()
    return [row[0].decode("ascii") if isinstance(row[0], bytes) else row[0] for row in rows]


def table_counts(connection: sqlite3.Connection) -> dict[str, int]:
    counts: dict[str, int] = {}
    for name in table_names(connection):
        counts[name] = connection.execute(f'SELECT count(*) FROM "{name}"').fetchone()[0]
    return counts


def digest_row_counts(counts: dict[str, int]) -> str:
    digest = hashlib.sha256()
    feed(digest, DIGEST_DOMAIN, "row-counts")
    for name in sorted(counts):
        feed(digest, name, counts[name])
    return digest.hexdigest()


def digest_snapshot_preserved(connection: sqlite3.Connection, pair_id: bytes) -> tuple[str, int]:
    """Ordered digest of every snapshot field except the observation seconds.

    Each row contributes side, path, fingerprint[8:] (nanoseconds, size and the
    exact stat key) and version.  The 8-byte little-endian seconds field is the
    only field the fixture ages, so it is the only field excluded here.
    """
    digest = hashlib.sha256()
    feed(digest, DIGEST_DOMAIN, "snapshot_entry", "preserved")
    feed(digest, pair_id)
    cursor = connection.execute(
        "SELECT side, path, fingerprint, version FROM snapshot_entry "
        "WHERE pair_id = ? ORDER BY side, path",
        (pair_id,),
    )
    rows = 0
    while True:
        batch = cursor.fetchmany(BATCH_ROWS)
        if not batch:
            break
        for side, path, fingerprint, version in batch:
            if len(fingerprint) < FINGERPRINT_HEADER_BYTES:
                fail("snapshot fingerprint shorter than its 20-byte header")
            feed(digest, side, path, bytes(fingerprint[8:]), version)
            rows += 1
    return digest.hexdigest(), rows


def digest_snapshot_seconds(connection: sqlite3.Connection, pair_id: bytes) -> tuple[str, int]:
    """Ordered digest of the observation seconds that are aged."""
    digest = hashlib.sha256()
    feed(digest, DIGEST_DOMAIN, "snapshot_entry", "seconds")
    feed(digest, pair_id)
    cursor = connection.execute(
        "SELECT side, path, fingerprint FROM snapshot_entry "
        "WHERE pair_id = ? ORDER BY side, path",
        (pair_id,),
    )
    rows = 0
    while True:
        batch = cursor.fetchmany(BATCH_ROWS)
        if not batch:
            break
        for side, path, fingerprint in batch:
            feed(digest, side, path, int.from_bytes(fingerprint[:8], "little"))
            rows += 1
    return digest.hexdigest(), rows


def digest_base_entry(connection: sqlite3.Connection, pair_id: bytes) -> tuple[str, int]:
    digest = hashlib.sha256()
    feed(digest, DIGEST_DOMAIN, "base_entry")
    feed(digest, pair_id)
    cursor = connection.execute(
        "SELECT path, left_version, right_version FROM base_entry "
        "WHERE pair_id = ? ORDER BY path",
        (pair_id,),
    )
    rows = 0
    while True:
        batch = cursor.fetchmany(BATCH_ROWS)
        if not batch:
            break
        for path, left_version, right_version in batch:
            feed(digest, path, left_version, right_version)
            rows += 1
    return digest.hexdigest(), rows


def digest_pair_config(connection: sqlite3.Connection) -> tuple[str, int, list[str]]:
    cursor = connection.execute("SELECT * FROM pair ORDER BY id")
    columns = [description[0] for description in cursor.description]
    digest = hashlib.sha256()
    feed(digest, DIGEST_DOMAIN, "pair-config")
    rows = 0
    while True:
        batch = cursor.fetchmany(BATCH_ROWS)
        if not batch:
            break
        for row in batch:
            feed(digest, *columns)
            feed(digest, *row)
            rows += 1
    return digest.hexdigest(), rows, columns


def digest_singleton_config(connection: sqlite3.Connection) -> str:
    digest = hashlib.sha256()
    feed(digest, DIGEST_DOMAIN, "singleton-config")
    for table in ("automation_hold", "automation_pause", "automation_setting",
                  "device", "share", "state_meta"):
        cursor = connection.execute(f'SELECT * FROM "{table}"')
        columns = [description[0] for description in cursor.description]
        feed(digest, table, *columns)
        for row in cursor.fetchall():
            feed(digest, *row)
    return digest.hexdigest()


def verify_source(connection: sqlite3.Connection, root: str) -> dict[str, object]:
    """Verify the closed catalog shape and return the chosen pair."""
    pending = connection.execute("SELECT count(*) FROM pending_pair").fetchone()[0]
    if pending:
        fail(f"source has {pending} pending_pair rows; expected a settled catalog")

    rows = connection.execute(
        "SELECT id, revision, name, left_root, right_root, mode, schedule "
        "FROM pair ORDER BY id"
    ).fetchall()
    if len(rows) != 1:
        fail(f"source has {len(rows)} pair rows; expected exactly one")

    pair_id, revision, name, left_root, right_root, mode, schedule = rows[0]
    if not isinstance(left_root, bytes) or not isinstance(right_root, bytes):
        fail("pair roots are not stored as bytes")
    if not left_root.startswith(b"/") or not right_root.startswith(b"/"):
        fail("pair is not LOCAL/local")

    expected_left = os.path.join(root, "native1m-aged", "source").encode("utf-8")
    expected_right = os.path.join(root, "native1m-aged", "right").encode("utf-8")
    if left_root != expected_left or right_root != expected_right:
        fail(
            "pair roots do not reference the owned native1m-aged source/right endpoints: "
            f"left={left_root!r} right={right_root!r}"
        )
    if schedule != "manual":
        fail(f"pair schedule is {schedule!r}; expected 'manual'")
    if not os.path.isdir(expected_left) or not os.path.isdir(expected_right):
        fail("owned source/right endpoint directories are missing")

    counts = {}
    for side in ("left", "right"):
        counts[side] = connection.execute(
            "SELECT count(*) FROM snapshot_entry WHERE pair_id = ? AND side = ?",
            (pair_id, side),
        ).fetchone()[0]
    for side, count in counts.items():
        if count < MIN_SNAPSHOT_ROWS_PER_SIDE:
            fail(f"snapshot rows for side {side!r}: {count}; expected >= {MIN_SNAPSHOT_ROWS_PER_SIDE}")

    short = connection.execute(
        "SELECT count(*) FROM snapshot_entry WHERE pair_id = ? AND length(fingerprint) < ?",
        (pair_id, FINGERPRINT_HEADER_BYTES),
    ).fetchone()[0]
    if short:
        fail(f"{short} snapshot fingerprints are shorter than the 20-byte header")

    return {
        "pair_id": pair_id,
        "revision": revision,
        "name": name,
        "left_root": left_root.decode("utf-8"),
        "right_root": right_root.decode("utf-8"),
        "mode": mode,
        "schedule": schedule,
        "snapshot_rows": counts,
    }


def clone_source(source_dir: str, destination_dir: str) -> None:
    if os.path.lexists(destination_dir):
        fail(f"destination already exists: {destination_dir}")
    parent = os.path.dirname(destination_dir)
    if not os.path.isdir(parent):
        fail(f"destination parent is missing: {parent}")
    command = ["cp", "-cR", source_dir, destination_dir]
    log("cloning: " + " ".join(command))
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        fail(
            "cp -cR failed with status "
            f"{result.returncode}: {result.stderr.decode('utf-8', 'replace').strip()}"
        )
    if not os.path.isdir(destination_dir):
        fail("cp -cR did not create the destination directory")
    # Transient SQLite side files copied from the source are not part of the
    # closed catalog; drop them from the clone only.
    for suffix in ("-shm", "-wal"):
        transient = os.path.join(destination_dir, "state.db" + suffix)
        if os.path.lexists(transient):
            os.remove(transient)


def age_snapshot_seconds(connection: sqlite3.Connection, pair_id: bytes) -> dict[str, object]:
    """Age only the 8-byte observation seconds of every snapshot fingerprint."""
    connection.execute("PRAGMA synchronous=FULL")
    connection.execute("PRAGMA wal_autocheckpoint=0")
    connection.execute("BEGIN IMMEDIATE")
    read_cursor = connection.cursor()
    write_cursor = connection.cursor()
    last_side = None
    last_path = None
    scanned = 0
    changed = 0
    violations = 0
    min_seconds = None
    max_seconds = None
    try:
        while True:
            if last_side is None:
                query = (
                    "SELECT side, path, fingerprint FROM snapshot_entry "
                    "WHERE pair_id = ? ORDER BY side, path LIMIT ?"
                )
                parameters = (pair_id, BATCH_ROWS)
            else:
                query = (
                    "SELECT side, path, fingerprint FROM snapshot_entry "
                    "WHERE pair_id = ? AND (side, path) > (?, ?) "
                    "ORDER BY side, path LIMIT ?"
                )
                parameters = (pair_id, last_side, last_path, BATCH_ROWS)
            batch = read_cursor.execute(query, parameters).fetchmany(BATCH_ROWS)
            if not batch:
                break
            parameters_out = []
            for side, path, fingerprint in batch:
                scanned += 1
                if len(fingerprint) < FINGERPRINT_HEADER_BYTES:
                    violations += 1
                    continue
                seconds = int.from_bytes(fingerprint[:8], "little")
                if seconds < DELTA_SECONDS:
                    violations += 1
                    continue
                new_seconds = seconds - DELTA_SECONDS
                new_fingerprint = new_seconds.to_bytes(8, "little") + bytes(fingerprint[8:])
                if new_fingerprint[8:] != bytes(fingerprint[8:]):
                    violations += 1
                parameters_out.append((new_fingerprint, pair_id, side, path))
                min_seconds = new_seconds if min_seconds is None else min(min_seconds, new_seconds)
                max_seconds = new_seconds if max_seconds is None else max(max_seconds, new_seconds)
            write_cursor.executemany(
                "UPDATE snapshot_entry SET fingerprint = ? "
                "WHERE pair_id = ? AND side = ? AND path = ?",
                parameters_out,
            )
            changed += len(parameters_out)
            last_side, last_path = batch[-1][0], batch[-1][1]
        connection.execute("COMMIT")
    except BaseException:
        connection.execute("ROLLBACK")
        raise
    return {
        "rows_scanned": scanned,
        "rows_changed": changed,
        "violations": violations,
        "min_seconds_after": min_seconds,
        "max_seconds_after": max_seconds,
    }


def capture_state(connection: sqlite3.Connection, pair_id: bytes) -> dict[str, object]:
    snapshot_preserved, snapshot_rows = digest_snapshot_preserved(connection, pair_id)
    snapshot_seconds, seconds_rows = digest_snapshot_seconds(connection, pair_id)
    base_digest, base_rows = digest_base_entry(connection, pair_id)
    pair_digest, pair_rows, pair_columns = digest_pair_config(connection)
    counts = table_counts(connection)
    return {
        "snapshot_preserved_digest": snapshot_preserved,
        "snapshot_rows": snapshot_rows,
        "snapshot_seconds_digest": snapshot_seconds,
        "snapshot_seconds_rows": seconds_rows,
        "base_entry_digest": base_digest,
        "base_entry_rows": base_rows,
        "pair_config_digest": pair_digest,
        "pair_rows": pair_rows,
        "pair_columns": pair_columns,
        "singleton_config_digest": digest_singleton_config(connection),
        "row_counts": counts,
        "row_counts_digest": digest_row_counts(counts),
    }


def write_json(path: str, payload: dict[str, object]) -> None:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=False)
        handle.write("\n")


def main() -> int:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=None, help="owned fixture root (default: lan-local.txt)")
    parser.add_argument("--source", default=None, help="source catalog directory")
    parser.add_argument("--destination", default=None, help="new destination catalog directory")
    parser.add_argument("--dry-run", action="store_true", help="verify and digest only; do not clone or mutate")
    args = parser.parse_args()

    root = args.root if args.root is not None else owned_root(script_dir)
    source_dir = args.source if args.source is not None else os.path.join(root, "native1m-aged", "service-union")
    destination_dir = args.destination if args.destination is not None else os.path.join(root, "native1m-aged", "agent-ipc")
    source_db = os.path.join(source_dir, "state.db")
    destination_db = os.path.join(destination_dir, "state.db")
    provenance_path = os.path.join(script_dir, "agent-ipc-fixture-provenance.json")
    fixture_path = os.path.join(script_dir, "agent-ipc-fixture.json")

    if not os.path.isdir(source_dir):
        fail(f"source catalog directory is missing: {source_dir}")
    if not os.path.isfile(source_db):
        fail(f"source state.db is missing: {source_db}")
    if os.path.lexists(destination_dir):
        fail(f"destination already exists (refusing to replace it): {destination_dir}")

    wal = os.path.join(source_dir, "state.db-wal")
    if os.path.exists(wal) and os.path.getsize(wal) != 0:
        fail(f"source catalog has a non-empty WAL; it is not closed: {wal}")
    source_journal_version = database_journal_version(source_db)
    if source_journal_version != 2:
        fail(f"source catalog is not in WAL mode (header read version {source_journal_version})")

    started = time.monotonic()
    log(f"owned root: {root}")
    log(f"source: {source_dir}")
    log(f"destination: {destination_dir}")

    source_before_hash = sha256_file(source_db)
    log(f"source state.db sha256: {source_before_hash}")

    source = connect_readonly(source_db)
    try:
        pair = verify_source(source, root)
        before = capture_state(source, pair["pair_id"])
    finally:
        source.close()
    pair["journal_mode"] = "wal"

    pair_id = pair["pair_id"]
    pair_id_hex = pair_id.hex() if isinstance(pair_id, bytes) else str(pair_id)
    log(
        "verified pair "
        f"{pair_id_hex} revision={pair['revision']} mode={pair['mode']} "
        f"schedule={pair['schedule']} snapshot_rows={pair['snapshot_rows']}"
    )
    log(
        "before digests: preserved="
        f"{before['snapshot_preserved_digest'][:16]}... base="
        f"{before['base_entry_digest'][:16]}... counts="
        f"{before['row_counts_digest'][:16]}..."
    )

    if args.dry_run:
        log("dry run: no clone and no mutation performed")
        return 0

    clone_source(source_dir, destination_dir)
    destination_after_clone_hash = sha256_file(destination_db)
    if destination_after_clone_hash != source_before_hash:
        fail("clone is not byte-identical to the source state.db")
    log(f"clone verified byte-identical: {destination_after_clone_hash}")

    connection = connect_readwrite(destination_db)
    try:
        journal_mode = connection.execute("PRAGMA journal_mode").fetchone()[0]
        if journal_mode != "wal":
            fail(f"destination journal_mode is {journal_mode!r}; expected 'wal'")
        mutation = age_snapshot_seconds(connection, pair_id)
        checkpoint = connection.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
        if checkpoint is None or checkpoint[0] != 0:
            fail(f"wal_checkpoint(TRUNCATE) did not complete: {checkpoint!r}")
        connection.close()
    finally:
        try:
            connection.close()
        except Exception:
            pass

    if mutation["violations"]:
        fail(f"mutation reported {mutation['violations']} violations")
    total_rows = before["snapshot_rows"]
    if mutation["rows_changed"] != total_rows or mutation["rows_scanned"] != total_rows:
        fail(
            "mutation row count mismatch: "
            f"scanned={mutation['rows_scanned']} changed={mutation['rows_changed']} expected={total_rows}"
        )

    destination_final_hash = sha256_file(destination_db)
    destination = connect_readonly(destination_db)
    try:
        after = capture_state(destination, pair_id)
        quick_check = destination.execute("PRAGMA quick_check").fetchone()[0]
        journal_mode_after = "wal" if database_journal_version(destination_db) == 2 else "delete"
    finally:
        destination.close()

    source_after_hash = sha256_file(source_db)
    if source_after_hash != source_before_hash:
        fail("source state.db changed during preparation")

    preserved_match = before["snapshot_preserved_digest"] == after["snapshot_preserved_digest"]
    base_match = before["base_entry_digest"] == after["base_entry_digest"]
    pair_match = before["pair_config_digest"] == after["pair_config_digest"]
    singleton_match = before["singleton_config_digest"] == after["singleton_config_digest"]
    counts_match = before["row_counts"] == after["row_counts"]
    counts_digest_match = before["row_counts_digest"] == after["row_counts_digest"]
    seconds_changed = before["snapshot_seconds_digest"] != after["snapshot_seconds_digest"]
    if not (preserved_match and base_match and pair_match and singleton_match and counts_match and counts_digest_match):
        fail(
            "preserved-state digest mismatch: "
            f"preserved={preserved_match} base={base_match} pair={pair_match} "
            f"singleton={singleton_match} counts={counts_match}"
        )
    if not seconds_changed:
        fail("snapshot observation seconds did not change")

    side_files = []
    for suffix in ("-shm", "-wal"):
        transient = os.path.join(destination_dir, "state.db" + suffix)
        if os.path.lexists(transient):
            side_files.append(os.path.basename(transient))

    elapsed = time.monotonic() - started
    log(f"mutation: {mutation['rows_changed']} rows aged by {DELTA_SECONDS}s ({DAYS} days)")
    log(
        "after digests: preserved="
        f"{after['snapshot_preserved_digest'][:16]}... base="
        f"{after['base_entry_digest'][:16]}... counts="
        f"{after['row_counts_digest'][:16]}..."
    )
    log(f"quick_check: {quick_check}; journal_mode: {journal_mode_after}; side files: {side_files}")
    log(f"source state.db unchanged: {source_after_hash}")
    log(f"destination state.db sha256 (clone): {destination_after_clone_hash}")
    log(f"destination state.db sha256 (final): {destination_final_hash}")
    log(f"elapsed: {elapsed:.1f}s")

    provenance = {
        "kind": "Isolated closed-catalog fixture for the agent IPC million-file preview",
        "created_utc": utc_now(),
        "owned_root": root,
        "source": {
            "catalog_dir": source_dir,
            "state_db": source_db,
            "state_db_sha256_before": source_before_hash,
            "state_db_sha256_after": source_after_hash,
            "source_unchanged": source_before_hash == source_after_hash,
            "clone_command": f"cp -cR {source_dir} {destination_dir}",
        },
        "destination": {
            "catalog_dir": destination_dir,
            "state_db": destination_db,
            "state_db_sha256_clone": destination_after_clone_hash,
            "state_db_sha256_final": destination_final_hash,
            "clone_sha256_match": destination_after_clone_hash == source_before_hash,
            "refused_existing": True,
        },
        "pair": {
            "id_hex": pair_id_hex,
            "revision": pair["revision"],
            "name": pair["name"],
            "left_root": pair["left_root"],
            "right_root": pair["right_root"],
            "mode": pair["mode"],
            "schedule": pair["schedule"],
            "local_local": True,
        },
        "verification": {
            "pair_count": 1,
            "pending_pair_count": 0,
            "schedule": pair["schedule"],
            "snapshot_rows_left": pair["snapshot_rows"]["left"],
            "snapshot_rows_right": pair["snapshot_rows"]["right"],
            "snapshot_rows_total": pair["snapshot_rows"]["left"] + pair["snapshot_rows"]["right"],
            "min_snapshot_rows_per_side": MIN_SNAPSHOT_ROWS_PER_SIDE,
            "shape_ok": True,
        },
        "mutation": {
            "table": "snapshot_entry",
            "column": "fingerprint",
            "recipe": (
                "for each row: seconds = u64_le(fingerprint[0:8]); "
                "require seconds >= 1814400; "
                "fingerprint' = (seconds - 1814400).to_bytes(8, 'little') + fingerprint[8:]; "
                "all other fingerprint bytes, versions, base rows and configuration unchanged"
            ),
            "days": DAYS,
            "seconds_subtracted": DELTA_SECONDS,
            "batch_rows": BATCH_ROWS,
            "rows_scanned": mutation["rows_scanned"],
            "rows_changed": mutation["rows_changed"],
            "violations": mutation["violations"],
            "min_seconds_after": mutation["min_seconds_after"],
            "max_seconds_after": mutation["max_seconds_after"],
            "nanoseconds_preserved": True,
            "fingerprint_tail_preserved": True,
        },
        "digests": {
            "algorithm": "sha256",
            "snapshot_preserved_before": before["snapshot_preserved_digest"],
            "snapshot_preserved_after": after["snapshot_preserved_digest"],
            "snapshot_preserved_match": preserved_match,
            "snapshot_seconds_before": before["snapshot_seconds_digest"],
            "snapshot_seconds_after": after["snapshot_seconds_digest"],
            "snapshot_seconds_changed": seconds_changed,
            "base_entry_before": before["base_entry_digest"],
            "base_entry_after": after["base_entry_digest"],
            "base_entry_match": base_match,
            "pair_config_before": before["pair_config_digest"],
            "pair_config_after": after["pair_config_digest"],
            "pair_config_match": pair_match,
            "singleton_config_before": before["singleton_config_digest"],
            "singleton_config_after": after["singleton_config_digest"],
            "singleton_config_match": singleton_match,
            "row_counts_before": before["row_counts"],
            "row_counts_after": after["row_counts"],
            "row_counts_match": counts_match,
            "row_counts_digest_before": before["row_counts_digest"],
            "row_counts_digest_after": after["row_counts_digest"],
            "row_counts_digest_match": counts_digest_match,
            "snapshot_rows": before["snapshot_rows"],
            "base_entry_rows": before["base_entry_rows"],
        },
        "wal": {
            "journal_mode_before": pair["journal_mode"],
            "journal_mode_after": journal_mode_after,
            "synchronous": "FULL",
            "checkpoint_result": list(checkpoint) if checkpoint else None,
            "checkpointed": True,
            "side_files_after": side_files,
        },
        "integrity": {
            "quick_check": quick_check,
        },
        "elapsed_seconds": elapsed,
        "paths": {
            "script": os.path.join(script_dir, "prepare-agent-ipc-fixture.py"),
            "lan_local": os.path.join(script_dir, "lan-local.txt"),
            "provenance": provenance_path,
            "fixture": fixture_path,
        },
    }
    write_json(provenance_path, provenance)

    fixture = {
        "pair_id": pair_id_hex,
        "state_path": destination_db,
        "catalog_dir": destination_dir,
        "name": pair["name"],
        "revision": pair["revision"],
        "left_root": pair["left_root"],
        "right_root": pair["right_root"],
        "mode": pair["mode"],
        "schedule": pair["schedule"],
        "snapshot_rows": {
            "left": pair["snapshot_rows"]["left"],
            "right": pair["snapshot_rows"]["right"],
            "total": pair["snapshot_rows"]["left"] + pair["snapshot_rows"]["right"],
        },
        "provenance": provenance_path,
        "created_utc": provenance["created_utc"],
    }
    write_json(fixture_path, fixture)
    log(f"wrote {provenance_path}")
    log(f"wrote {fixture_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except FixtureError as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(2)
