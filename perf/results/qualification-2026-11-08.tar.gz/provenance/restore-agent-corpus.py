"""Unlicense. Create an owned persistent corpus from the intact source clone."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import tempfile
import time

repo=Path.cwd();work=repo/'build/performance-work'
old=Path((work/'lan-local.txt').read_text().strip())
source=old/'corpus1m'
parent=Path.home()/'.local/share'
assert parent.is_dir() and source.stat().st_dev==parent.stat().st_dev
owned=Path(tempfile.mkdtemp(prefix='foldover-perf-agent-',dir=parent))
(work/'agent-persistent-root.txt').write_text(str(owned)+'\n')
fixture=owned/'native1m-aged';fixture.mkdir()
old_counts={}
for side in ['source','right']:
 count=0
 for directory,dirs,files in os.walk(old/'native1m-aged'/side):
  dirs[:]=[name for name in dirs if name!='.foldover']
  count+=len(files)
 old_counts[side]=count
age_ns=time.time_ns()-30*24*3600*1_000_000_000
counts={}
for side in ['source','right']:
 target=fixture/side
 subprocess.run(['cp','-cRp',str(source),str(target)],check=True)
 internal=target/'.foldover'
 if internal.exists():shutil.rmtree(internal)
 count=0
 for directory,dirs,files in os.walk(target):
  assert '.foldover' not in dirs
  for name in files:
   path=Path(directory)/name
   assert stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size==8192
   os.utime(path,ns=(time.time_ns(),age_ns))
   count+=1
 assert count==1_000_000,(side,count)
 counts[side]=count
 print('Restored and aged',side,count,flush=True)
provenance=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),owned_root=str(owned),intact_clone_source=str(source),previous_aged_temporary_tree_file_counts=old_counts,new_regular_file_counts=counts,bytes_per_file=8192,mtime_ns=age_ns,recipe='APFS cp -cRp of the intact original corpus into two new owned persistent roots; remove only cloned .foldover identities before opening either root, age only regular-file mtimes by 30 days, retain current access times. Original source remains unchanged. Persistent location avoids relying on aged files in the macOS temporary directory.',cause_of_missing_previous_files='Unknown; no cause is claimed',state_seed='Fresh production engine catalog; matching populated roots, no copied old fingerprints')
(work/'agent-persistent-corpus-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
command=['python3','perf/run-qualification.py','--runner',str(work/'bin/qualified-final'),'--state',str(fixture/'service-union'),'--left',str(fixture/'source'),'--right',str(fixture/'right'),'--iterations','1','--output',str(work/'agent1m-persistent-seed'),'--label','Fresh real million-file persistent local corpus; baseline seed; no physical file copies expected; files aged 30 days','--revision','4dcca23']
result=subprocess.run(command)
summary=json.loads((work/'agent1m-persistent-seed/summary.json').read_text())
assert result.returncode==0 and summary['returncode']==0
lines=[line.split('\t') for line in (work/'agent1m-persistent-seed/runner.tsv').read_text().splitlines() if line.startswith('result\t')]
assert len(lines)==1 and lines[0][2:5]==['0','0','0'],lines
print('Fresh persistent million-file catalog seeded',flush=True)
