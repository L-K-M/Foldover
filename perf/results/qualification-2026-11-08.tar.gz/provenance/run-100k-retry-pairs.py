from pathlib import Path
import hashlib,json,re,subprocess,time
root=Path.cwd();w=root/'build/performance-work'
long=json.loads((w/'lan1m-client-debug/summary.json').read_text());assert long['returncode']==0, 'resolve the final 1M failure first'
rss=re.search(r'^\s*(\d+)\s+maximum resident set size',(w/'lan1m-client-debug/resources.txt').read_text(),re.M)
assert rss and int(rss[1])<500_000_000, 'resolve the final 1M memory gate first'
local_ready=w/'local-background-ready.json'
print('Waiting for the local agent qualification before paired NAS timing',flush=True)
while not local_ready.exists():time.sleep(5)
ready=json.loads(local_ready.read_text())
assert ready['comparison_candidate_ready'], 'resolve the agent qualification before comparison'
for name in ['lan-reverse10k-final','lan-largefile-final']:
 assert json.loads((w/name/'summary.json').read_text())['returncode']==0,'finish other NAS qualification first'
local=Path((w/'lan-local.txt').read_text().strip());nas=(w/'lan-root.txt').read_text().strip()
old=json.loads((w/'lan100k-paired/0-before/summary.json').read_text())
before=Path(old['command'][0]);after=w/'bin/qualified-early-comparison'
assert hashlib.sha256(before.read_bytes()).hexdigest()==old['binary_sha256'], 'original baseline binary changed'
new=json.loads((w/'qualified-early-comparison-provenance.json').read_text())
assert hashlib.sha256(after.read_bytes()).hexdigest()==new['binary_sha256'], 'qualified binary changed'
assert ready['after_revision']==new['revision'] and ready['after_binary_sha256']==new['binary_sha256']
namespace=local/'comparison100k-final';namespace.mkdir()
provenance={'seed':'Closed original state100k catalog cloned separately for each sample; no corpus mutations','order':[],'before_revision':old['revision'],'before_sha256':old['binary_sha256'],'after_revision':new['revision'],'after_sha256':new['binary_sha256'],'scope':'Shared host, uncontrolled caches, complete no-change runs over the same 100k corpus. Combined baseline-to-current comparison, not isolation of one optimization.'}
output=w/'lan100k-retry-paired';output.mkdir()
for pair in range(3):
 for variant in (['before','after'] if pair%2==0 else ['after','before']):
  state=namespace/f'{pair}-{variant}';subprocess.run(['cp','-cR',str(local/'state100k'),str(state)],check=True)
  binary,revision=(before,old['revision']) if variant=='before' else (after,new['revision'])
  case=f'{pair}-{variant}';provenance['order'].append(case)
  (output/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
  command=['python3','perf/run-qualification.py','--runner',str(binary),'--state',str(state),'--left',str(local/'corpus100k'),'--right',f'sftp://benchmark@nas.invalid{nas}/corpus100k','--iterations','1','--output',str(output/case),'--label',f'100k paired retry {case}; same closed seed and corpus; shared host','--revision',revision]
  result=subprocess.run(command,check=False)
  summary=json.loads((output/case/'summary.json').read_text())
  lines=[line.split('\t') for line in (output/case/'runner.tsv').read_text().splitlines() if line.startswith('result\t')]
  if result.returncode or summary['returncode'] or len(lines)!=1 or lines[0][2:5]!=['0','0','0']:
   raise SystemExit(f'{case} failed or proposed unexpected writes; artifacts retained; comparison stopped')
print('All three 100k baseline/current pairs completed')
