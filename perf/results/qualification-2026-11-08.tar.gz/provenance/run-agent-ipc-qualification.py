"""Unlicense. Measure an isolated signed agent, without installation or GUI."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time
import uuid

root = Path.cwd()
work = root / "build/performance-work"
spec = importlib.util.spec_from_file_location("qualification", root / "perf/run-qualification.py")
qualification = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qualification)
fixture = json.loads((work / "agent-ipc-run-fixture.json").read_text())
selection = json.loads((work / "agent-probe-selection.json").read_text())
state = Path(fixture["catalog_dir"])
pair_id = fixture["pair_id"]
assert "foldover-perf" in str(state) and state.is_dir()
physical_file_counts={}
for side,key in [("left","left_root"),("right","right_root")]:
    count=0
    for directory,dirs,files in os.walk(fixture[key]):
        dirs[:]=[name for name in dirs if name!=".foldover"]
        count+=len(files)
    if count < 1_000_000:
        raise RuntimeError(f"{side} physical corpus has {count} files; require at least one million")
    physical_file_counts[side]=count
bundle = (work / "agent-ipc-private/Qualification.app").resolve()
agent = bundle / "Contents/Library/LaunchServices/foldoverd"
cli = bundle / "Contents/Library/LaunchServices/foldover"
provenance = json.loads((work / selection["build_provenance"]).read_text())
for role, binary in [("agent", agent), ("cli", cli)]:
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == provenance["roles"][role]["binary_sha256"]
case=selection["output_case"]
assert case.startswith("agent1m-") and Path(case).name==case
output = work / case
output.mkdir()
runtime = Path(tempfile.mkdtemp(prefix="foldover-perf-ipc-"))
(work / "agent-ipc-runtime-root.txt").write_text(str(runtime) + "\n")
registry=work/"agent-ipc-runtime-roots.json"
roots=json.loads(registry.read_text()) if registry.exists() else []
roots.append(str(runtime));registry.write_text(json.dumps(roots,indent=2)+"\n")
endpoint = runtime / "s"
assert len(os.fsencode(endpoint)) < 100
summary = dict(
    label="Real isolated signed agent: expired million-file local preview, real authenticated CLI/IPC, scheduler active; private uninstalled bundle; app stub never launched",
    revision=provenance["base_commit"] + "+" + selection["source_patch"],
    binary_sha256=provenance["roles"]["agent"]["binary_sha256"],
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    measurements=[], sampling_errors=[], parsing_errors=[], cleanup_errors=[],
    sampled_peak_ssh_children=0,
    physical_file_counts_before_start=physical_file_counts,
)
started = time.monotonic()
preview = None
process = None
agent_pid = None
poll_latencies = []
error = None
trace = (output / "runner.tsv").open("x")
samples = (output / "samples.jsonl").open("x")
resources = (output / "resources.txt").open("x")
agent_stdout = (output / "agent.stdout").open("x")
preview_stdout = (output / "preview.json").open("x")
preview_stderr = (output / "preview.stderr").open("x")


def metric(name, seconds):
    ns = int(seconds * 1_000_000_000)
    trace.write(f"metric\t0\t{name}\t{ns}\n")
    trace.flush()
    summary["measurements"].append(dict(event="metric", iteration=0, phase=name, ns=ns))


def invoke(arguments):
    return subprocess.run([str(cli), *arguments, "--socket", str(endpoint)], capture_output=True, text=True, timeout=15)


def own_agent_pid():
    rows = subprocess.check_output(["ps", "-axo", "pid=,ppid=,comm="], text=True)
    for row in rows.splitlines():
        fields = row.strip().split(None, 2)
        if len(fields) == 3 and int(fields[1]) == process.pid and Path(fields[2]).name == "foldoverd":
            return int(fields[0])
    return None


try:
    command = ["/usr/bin/time", "-l", str(agent), "--socket", str(endpoint)]
    summary["command"] = command
    process = subprocess.Popen(command, env=dict(os.environ, FOLDOVER_PERF_AGENT_STATE=str(state)), stdout=agent_stdout, stderr=resources, start_new_session=True)
    startup_deadline = time.monotonic() + 30
    while True:
        status = invoke(["status"])
        if status.returncode == 0:
            break
        if process.poll() is not None or time.monotonic() > startup_deadline:
            raise RuntimeError("Isolated agent did not become reachable: " + status.stderr)
        time.sleep(0.2)
    metric("AgentStartup", time.monotonic() - started)
    agent_pid = own_agent_pid()
    if agent_pid is None:
        raise RuntimeError("Cannot identify the owned timed agent process")
    pairs = invoke(["pairs"])
    if pairs.returncode:
        raise RuntimeError("Normal privileged IPC authentication failed: " + pairs.stderr)
    records = [json.loads(line) for line in pairs.stdout.splitlines() if line.strip()]
    assert len(records) == 1 and uuid.UUID(records[0]["id"]) == uuid.UUID(pair_id)
    pair_id = records[0]["id"]
    preview_started = time.monotonic()
    preview = subprocess.Popen([str(cli), "sync", pair_id, "--preview", "--socket", str(endpoint)], stdout=preview_stdout, stderr=preview_stderr, start_new_session=True)
    deadline = preview_started + 900
    while preview.poll() is None:
        if time.monotonic() > deadline:
            raise TimeoutError("Agent preview exceeded fifteen minutes")
        poll_started = time.monotonic()
        status = invoke(["status"])
        latency = time.monotonic() - poll_started
        poll_latencies.append(latency)
        if status.returncode:
            raise RuntimeError("Agent status failed during preview: " + status.stderr)
        sample = dict(elapsed_seconds=time.monotonic()-started, status_round_trip_including_cli_start_seconds=latency)
        ps = subprocess.run(["ps", "-p", str(agent_pid), "-o", "rss=,pcpu="], capture_output=True, text=True)
        if ps.returncode:
            summary["sampling_errors"].append("ps exited " + str(ps.returncode))
        else:
            fields = ps.stdout.split()
            sample.update(agent_rss_kib=int(fields[0]), agent_os_cpu_percent=float(fields[1]))
        samples.write(json.dumps(sample)+"\n"); samples.flush()
        time.sleep(1)
    metric("AgentPreviewIPC", time.monotonic()-preview_started)
    preview_stdout.flush(); preview_stderr.flush()
    if preview.returncode:
        raise RuntimeError("CLI preview failed: " + (output/"preview.stderr").read_text())
    result = json.loads((output/"preview.json").read_text())
    assert result["state"] == "previewed", result
    value = result["preview"]
    assert all(number == 0 for number in value["counts"].values()), value["counts"]
    assert value.get("failure_count", 0) == 0 and not value.get("failures")
    assert value["left"]["paths"] >= 1_000_000 and value["right"]["paths"] >= 1_000_000
    metric("MaximumStatusRoundTripIncludingClientStart", max(poll_latencies, default=0))
    # Keep the agent alive after the client exits, with its preview retained.
    time.sleep(2)
    (output/"checks.json").write_text(json.dumps(dict(privileged_authentication_passed=True, preview_state=result["state"], counts=value["counts"], left_paths=value["left"]["paths"], right_paths=value["right"]["paths"], status_poll_count=len(poll_latencies), held_after_client_exit_seconds=2),indent=2)+"\n")
except BaseException as exception:
    error = repr(exception)
finally:
    try:
        qualification.stop_child_group(preview, summary["cleanup_errors"])
    except BaseException as exception:
        summary["cleanup_errors"].append(repr(exception))
    try:
        if process is not None and process.poll() is None:
            actual_pid = own_agent_pid()
            if actual_pid is not None:
                os.kill(actual_pid, signal.SIGTERM)
                process.wait(timeout=20)
            else:
                raise RuntimeError("Timed process alive without its owned agent")
    except BaseException as exception:
        summary["cleanup_errors"].append(repr(exception))
        qualification.stop_child_group(process, summary["cleanup_errors"])
    finally:
        for handle in [samples,resources,agent_stdout,preview_stdout,preview_stderr]:handle.close()
    metric("Total", time.monotonic()-started)
    trace.close()
    summary.update(elapsed_seconds=time.monotonic()-started, returncode=1 if error or summary["cleanup_errors"] else process.returncode, error=error)
    (output/"summary.json").write_text(json.dumps(summary,indent=2)+"\n")
print(json.dumps(dict(returncode=summary["returncode"], error=error, measurements=summary["measurements"])))
raise SystemExit(summary["returncode"])
