from pathlib import Path
import hashlib,json,shlex,subprocess
root=Path.cwd();w=root/'build/performance-work'
assert (w/'lan1m-final/summary.json').is_file(), 'long NAS qualification still active'
probes=list((w/'ssh-packet-pairs').glob('*/summary.json'));assert len(probes)==6 and all(json.loads(p.read_text())['returncode']==0 for p in probes), 'packet probes must finish first'
local=Path((w/'lan-local.txt').read_text().strip());nas=(w/'lan-root.txt').read_text().strip()
assert local.name.startswith('foldover-perf-') and nas=='$NAS_FIXTURE'
binary=w/'bin/qualification-counters';rev='292d24b';target='benchmark@nas.invalid'
# A fresh local target; the remote source is the existing owned 10k corpus.
reverse=local/'reverse10k-final';reverse.mkdir()
command=['python3','perf/run-qualification.py','--runner',str(binary),'--state',str(local/'state-reverse10k-final'),'--left',f'sftp://{target}{nas}/dev10k','--right',str(reverse),'--iterations','2','--output',str(w/'lan-reverse10k-final'),'--label','Shared-host SFTP-to-local 10k initial copy then no change; not a paired speed comparison','--revision',rev]
subprocess.run(command,check=True)
def files(path):
 return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in path.rglob('*') if p.is_file() and '.foldover' not in p.relative_to(path).parts}
assert files(reverse)==files(local/'dev10k'), 'reverse copy differs from the original owned corpus'
source=local/'largefile-final';source.mkdir()
for i in range(16):
 (source/f'large-{i:02}.bin').write_bytes(hashlib.shake_256(f'foldover-largefile-{i}'.encode()).digest(16*1024*1024))
remote=nas+'/largefile-final'
script="from pathlib import Path;import sys;p=Path(sys.argv[1]);assert str(p.parent)=='$NAS_FIXTURE';assert p.name=='largefile-final';p.mkdir()"
remote_command='python3 -c '+shlex.quote(script)+' '+shlex.quote(remote)
subprocess.run(['ssh','-o','BatchMode=yes','-o','ServerAliveInterval=15',target,remote_command],check=True)
command=['python3','perf/run-qualification.py','--runner',str(binary),'--state',str(local/'state-largefile-final'),'--left',str(source),'--right',f'sftp://{target}{remote}','--iterations','2','--output',str(w/'lan-largefile-final'),'--label','Shared-host local-to-SFTP 16 x 16 MiB unique files; initial copy then full-content no-change check; not idle-host throughput qualification','--revision',rev]
subprocess.run(command,check=True)
for name in ['lan-reverse10k-final','lan-largefile-final']:
 s=json.loads((w/name/'summary.json').read_text());assert s['returncode']==0
 results=[line.split('\t') for line in (w/name/'runner.tsv').read_text().splitlines() if line.startswith('result\t')]
 assert len(results)==2 and results[1][2:5]==['0','0','0'],results
 if name=='lan-largefile-final':assert results[0][2:5]==['16','0','0'],results
(w/'lan-extended-provenance.json').write_text(json.dumps({'binary_revision':rev,'reverse10k':'Existing owned dev10k source; target content/path SHA256 maps matched original local source; second iteration reported no changes.','largefile':'16 distinct deterministic SHAKE-256 files of 16 MiB each; second iteration reread remote content and reported no changes.','scope':'Shared busy host; two iterations per case, no paired speedup or idle/cold throughput claim.'},indent=2)+'\n')
print('Reverse-copy and large-file qualification completed')
