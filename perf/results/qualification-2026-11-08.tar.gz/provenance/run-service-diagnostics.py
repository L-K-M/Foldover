from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,time
root=Path.cwd(); work=root/'build/performance-work'
fixture=Path((work/'lan-local.txt').read_text().strip())/'native1m-aged'
state=fixture/'service-diagnostics'
assert not state.exists()
subprocess.run(['cp','-cR',str(fixture/'service-union'),str(state)],check=True)
spec=importlib.util.spec_from_file_location('qualification',root/'perf/run-qualification.py'); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
binary=Path((work/'diagnostics-service-executable.txt').read_text().strip())
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
failures=[]
for name,test in [('service1m-input-lock','million_file_service_input_lock'),('service1m-scan-cancellation','million_file_service_scan_cancellation')]:
 output=work/name;output.mkdir()
 command=['/usr/bin/time','-l',str(binary),'--ignored','--exact','performance_tests::'+test,'--nocapture']
 summary=dict(label='Focused real million-file local Service diagnostic: '+test,command=command,revision=revision,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),measurements=[],parsing_errors=[],sampling_errors=[],cleanup_errors=[],source_files={'crates/foldover-service/src/performance_tests.rs':hashlib.sha256((root/'crates/foldover-service/src/performance_tests.rs').read_bytes()).hexdigest()})
 started=time.monotonic()
 with (output/'runner.tsv').open('x') as stdout,(output/'resources.txt').open('x') as stderr:
  try:
   result=subprocess.run(command,stdout=stdout,stderr=stderr,env=dict(os.environ,FOLDOVER_PERF_SERVICE_STATE=str(state)),timeout=120)
   summary['returncode']=result.returncode
  except subprocess.TimeoutExpired:
   summary.update(returncode=124,error='Diagnostic exceeded two minutes')
 for number,line in enumerate((output/'runner.tsv').read_text().splitlines(),1):
  try:record=module.parse_record(line,number)
  except module.ParseError as error:
   summary['parsing_errors'].append(str(error));continue
  if record and record[0]!='process':
   point=dict(event=record[0],iteration=record[1],phase=record[2]);point['value' if record[0]=='counter' else 'ns']=record[3];summary['measurements'].append(point)
 summary['elapsed_seconds']=time.monotonic()-started
 (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(name,summary['returncode'],summary['measurements'],flush=True)
 if summary['returncode'] or summary['parsing_errors']:failures.append(name)
raise SystemExit(bool(failures))
