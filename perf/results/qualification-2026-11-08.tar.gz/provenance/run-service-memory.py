import pathlib,json,hashlib,subprocess,os,datetime,time,sys
work=pathlib.Path('build/performance-work')
label=sys.argv[1]; state=sys.argv[2]; build=work/sys.argv[3]
artifacts=[json.loads(l) for l in build.read_text().splitlines() if l.startswith('{')]
binaries=[e['executable'] for e in artifacts if e.get('reason')=='compiler-artifact' and e.get('target',{}).get('name')=='foldover_service' and e.get('executable')]
assert len(binaries)==1
binary=pathlib.Path(binaries[0]); root=pathlib.Path((work/'lan-local.txt').read_text().strip())
output=work/label; output.mkdir()
command=['/usr/bin/time','-l',str(binary),'--ignored','--exact','performance_tests::million_file_service_preview','--nocapture']
summary={'label':'Real 1m expired native/native service preview; held preview, concurrent status and scheduler-delay measurements; exact initial plan reservation','command':command,'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'+plan-reservation-and-service-test','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'measurements':[],'parsing_errors':[],'sampling_errors':[],'cleanup_errors':[],'source_files':{name:hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest() for name in ['crates/foldover-engine/src/plan.rs','crates/foldover-service/src/lib.rs','crates/foldover-service/src/performance_tests.rs']}}
started=time.monotonic()
with (output/'runner.tsv').open('x') as out,(output/'resources.txt').open('x') as err:
 result=subprocess.run(command,stdout=out,stderr=err,env=dict(os.environ,FOLDOVER_PERF_SERVICE_STATE=str(root/'native1m-aged'/state)))
summary['returncode']=result.returncode;summary['elapsed_seconds']=time.monotonic()-started
fields={'preview':'ServicePreview','maximum_status_ns':'MaximumStatusLatency','maximum_poll_delay_ns':'MaximumPollDelay'}
for line in (output/'runner.tsv').read_text().splitlines():
 bits=line.split('\t')
 if bits[0] in fields:summary['measurements'].append({'phase':fields[bits[0]],'ns':int(bits[1])})
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('service qualification returncode',result.returncode)
raise SystemExit(result.returncode)
