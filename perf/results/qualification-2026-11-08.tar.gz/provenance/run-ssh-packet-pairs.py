from pathlib import Path
import collections,csv,datetime,hashlib,importlib.util,json,subprocess,time
root=Path.cwd();work=root/'build/performance-work'
spec=importlib.util.spec_from_file_location('qualification',root/'perf/run-qualification.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
# The long engine run must have ended before any additional NAS session starts.
assert (work/'lan1m-final/summary.json').is_file(), 'long NAS qualification still active'
local=Path((work/'lan-local.txt').read_text().strip())/'corpus1m'
folder=next(p for p in local.iterdir() if p.is_dir() and not p.name.startswith('.'))
file=next(p for p in folder.iterdir() if p.is_file() and not p.name.startswith('.'))
remote=(work/'lan-root.txt').read_text().strip()+'/corpus1m/'+str(file.relative_to(local))
expected=file.stat().st_size;assert expected==8192
binary=work/'bin/ssh-packet-probe';revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
rounds=100
for pair in range(3):
 for mode in (['bounded','unknown'] if pair%2==0 else ['unknown','bounded']):
  output=work/'ssh-packet-pairs'/f'{pair}-{mode}';output.mkdir(parents=True)
  frames=output/'events.jsonl'
  command=[str(binary),'benchmark@nas.invalid',remote,str(rounds),mode,'--relay',str(root/'perf/sftp-relay.py'),str(frames)]
  summary=dict(label='Read-only SSH packet-count probe; '+mode+'; 100 rounds; relay overhead included',command=command,revision=revision,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),measurements=[],parsing_errors=[],sampling_errors=[],cleanup_errors=[],scope='SFTP framing and payload bytes, not encrypted network bytes or RTT; peak excludes SSH/relay children')
  started=time.monotonic()
  with (output/'probe.csv').open('x') as stdout,(output/'resources.txt').open('x') as stderr:
   child=None
   try:
    child=subprocess.Popen(['/usr/bin/time','-l',*command],stdout=stdout,stderr=stderr,start_new_session=True)
    summary['returncode']=child.wait(timeout=120)
   except subprocess.TimeoutExpired:
    summary.update(returncode=124,error='Packet probe exceeded two minutes')
   except OSError as error:
    summary.update(returncode=127,error=f'Packet probe launch failed: {error}')
   finally:
    module.stop_child_group(child,summary['cleanup_errors'])
  summary['elapsed_seconds']=time.monotonic()-started
  try:
   rows=list(csv.DictReader((output/'probe.csv').open()))
   assert len(rows)==rounds and [int(r['round']) for r in rows]==list(range(rounds)), 'incomplete rounds'
   assert all(int(r['data_bytes'])==expected for r in rows), 'unexpected delivered payload count'
   events=[json.loads(line) for line in frames.read_text().splitlines()]
   request=collections.Counter(e['kind'] for e in events if e['event']=='request')
   response=collections.Counter(e['kind'] for e in events if e['event']=='response')
   data_bytes=sum(e.get('data_bytes',0) for e in events if e['event']=='response' and e['kind']==103)
   assert data_bytes==rounds*expected, 'unexpected DATA frame payload count'
   if mode=='bounded':assert request[5]==2*rounds, 'bounded READ budget changed'
   assert all(e['outstanding']<=16 for e in events), 'window exceeded'
   assert events[-1]['outstanding']==0, 'undrained replies'
   counters={'ProbeRounds':rounds,'ReadRequests':request[5],'DataResponses':response[103],'DataPayloadBytes':data_bytes,'FramedRequestBytes':sum(e['bytes'] for e in events if e['event']=='request'),'FramedResponseBytes':sum(e['bytes'] for e in events if e['event']=='response'),'PeakOutstandingRequests':max(e['outstanding'] for e in events)}
   summary['measurements']=[dict(event='counter',iteration=0,phase=k,value=v) for k,v in counters.items()]
   summary['request_counts']={str(k):v for k,v in request.items()};summary['response_counts']={str(k):v for k,v in response.items()}
  except Exception as error:
   summary['parsing_errors'].append(f'{type(error).__name__}: {error}')
  (output/'runner.tsv').write_text(''.join(f"counter\t0\t{m['phase']}\t{m['value']}\n" for m in summary['measurements']))
  (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
  print(output.name,summary['returncode'],summary['measurements'],summary['parsing_errors'],flush=True)
  if summary['returncode'] or summary['parsing_errors'] or summary['cleanup_errors']:raise SystemExit(1)
