use std::time::Instant;
use foldover_engine::{Engine, StateLocation};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("process\t{}", std::process::id());
    let state = std::env::args_os().nth(1).expect("synthetic state directory");
    let path = std::path::PathBuf::from(state);
    assert!(path.file_name().is_some_and(|name| name == "state-load-1m"));
    assert!(path.components().any(|part| part.as_os_str().to_string_lossy().starts_with("foldover-perf")));
    let engine = Engine::open(&StateLocation::Directory(path))?;
    let pairs = engine.pairs()?;
    assert_eq!(pairs.len(), 1);
    let started = Instant::now();
    let records = engine.capture_run_inputs(pairs[0].id())?;
    println!("metric\t0\tInputCapture\t{}", started.elapsed().as_nanos());
    let started = Instant::now();
    let inputs = records.decode()?;
    println!("metric\t0\tInputDecode\t{}", started.elapsed().as_nanos());
    std::hint::black_box(&inputs);
    println!("loaded\t0");
    Ok(())
}
