import argparse,json,pathlib,re,statistics
parser=argparse.ArgumentParser();parser.add_argument('--supervisor-returncode',required=True,type=int);args=parser.parse_args()
w=pathlib.Path(__file__).resolve().parent;root=w/'lan100k-retry-paired'
provenance=json.loads((root/'provenance.json').read_text())
cases={};completed=sorted(p.parent.name for p in root.glob('*/summary.json'))
for name in completed:
 folder=root/name;s=json.loads((folder/'summary.json').read_text())
 variant=name.split('-')[1]
 assert s['binary_sha256']==provenance[variant+'_sha256'],name
 metrics={m['phase']:m['ns']/1e9 for m in s.get('measurements',[]) if 'ns' in m}
 lines=[line.split('\t') for line in (folder/'runner.tsv').read_text().splitlines() if line.startswith('result\t')]
 rss=re.search(r'^\s*(\d+)\s+maximum resident set size',(folder/'resources.txt').read_text(),re.M)
 cases[name]={'returncode':s['returncode'],'total_s':metrics.get('Total'),'observe_right_s':metrics.get('ObserveRight'),'observe_left_s':metrics.get('ObserveLeft'),'apply_s':metrics.get('Apply'),'kernel_peak_rss_bytes':int(rss[1]) if rss else None,'results':lines}
expected={f'{i}-{v}' for i in range(3) for v in ['before','after']}
valid=args.supervisor_returncode==0 and set(completed)==expected
if valid:
 for name,c in cases.items():
  assert c['returncode']==0 and len(c['results'])==1 and c['results'][0][2:5]==['0','0','0'],name
  assert all(c[field] is not None for field in ['total_s','observe_right_s','kernel_peak_rss_bytes']),name
stats={}
if valid:
 for variant in ['before','after']:
  selected=[cases[f'{i}-{variant}'] for i in range(3)]
  stats[variant]={}
  for field in ['total_s','observe_right_s','observe_left_s','apply_s','kernel_peak_rss_bytes']:
   values=[c[field] for c in selected];stats[variant][field]={'samples':values,'median':statistics.median(values),'min':min(values),'max':max(values)}
final={'collection_finished':True,'supervisor_returncode':args.supervisor_returncode,'comparison_complete':valid,'completed_cases':completed,'order':provenance['order'],'cases':cases,'statistics':stats,'limits':'Shared host and uncontrolled OS caches; combined baseline-to-current comparison, not isolation of a single optimization. Failed or partial collections have no aggregate speedup.'}
(w/'lan100k-retry-final-status.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps(final,indent=2))
