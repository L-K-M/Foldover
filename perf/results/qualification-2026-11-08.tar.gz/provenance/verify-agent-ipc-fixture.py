"""Unlicense. Independent streaming verification of the aged catalog."""
import datetime
import hashlib
import itertools
import json
from pathlib import Path
import sqlite3
import time

w=Path('build/performance-work')
f=json.loads((w/'agent-ipc-fixture.json').read_text())
p=json.loads((w/'agent-ipc-fixture-provenance.json').read_text())
src=Path(p['source']['state_db']);dst=Path(f['state_path']);started=time.monotonic()
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def ro(path):return sqlite3.connect(path.as_uri()+'?mode=ro&immutable=1',uri=True)
a=ro(src);b=ro(dst)
assert sha(src)==p['source']['state_db_sha256_before']
q='select pair_id,side,path,fingerprint,version from snapshot_entry order by pair_id,side,path'
count=0
for left,right in itertools.zip_longest(a.execute(q),b.execute(q)):
 assert left is not None and right is not None
 assert left[:3]==right[:3] and left[4]==right[4]
 assert len(left[3])>=20 and left[3][8:]==right[3][8:]
 assert int.from_bytes(left[3][:8],'little')-int.from_bytes(right[3][:8],'little')==1814400
 count+=1
assert count==2002000
counts={}
for (name,) in a.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%' order by name"):
 if name=='snapshot_entry':continue
 quoted='"'+name.replace('"','""')+'"'
 cols=list(a.execute('pragma table_info('+quoted+')'))
 keys=sorted((row[5],row[1]) for row in cols if row[5])
 order=','.join('"'+name.replace('"','""')+'"' for _,name in keys) if keys else 'rowid'
 query='select * from '+quoted+' order by '+order
 n=0
 for left,right in itertools.zip_longest(a.execute(query),b.execute(query)):
  assert left is not None and left==right,name
  n+=1
 counts[name]=n
assert b.execute('pragma quick_check').fetchone()[0]=='ok'
a.close();b.close()
assert src.open('rb').read(20)[18:20]==b'\2\2'
assert dst.open('rb').read(20)[18:20]==b'\2\2'
source_sha=sha(src);destination_sha=sha(dst)
assert source_sha==p['source']['state_db_sha256_before'] and source_sha!=destination_sha
result=dict(verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),snapshot_rows_compared=count,timestamp_delta_seconds=1814400,exact_fingerprint_tail_and_version_match=True,other_tables_exact_match=counts,source_database_sha256=source_sha,aged_database_sha256=destination_sha,persistent_journal_modes='WAL on source and aged destination, header read/write versions 2/2; immutable reader PRAGMA mode is not persistent mode',elapsed_seconds=time.monotonic()-started)
(w/'agent-ipc-persistent-parent-provenance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
