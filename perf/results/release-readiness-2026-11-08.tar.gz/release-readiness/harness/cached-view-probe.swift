// Unlicense. A diagnostic for cached catalog accessibility readiness.
import AppKit
import ApplicationServices
import Foundation

@MainActor
private func catalogIsReady(_ pid: pid_t, label: String) -> Bool {
    let app = AXUIElementCreateApplication(pid)
    var raw: CFTypeRef?
    guard AXUIElementCopyAttributeValue(app, kAXWindowsAttribute as CFString, &raw) == .success,
          let windows = raw as? [AXUIElement] else { return false }
    var pending: [(AXUIElement, Int)] = windows.map { ($0, 0) }
    var inspected = 0
    while let (node, depth) = pending.popLast(), inspected < 1000 {
        inspected += 1
        // A restored window title alone does not prove its catalog loaded.
        if depth > 0 {
            for key in [kAXDescriptionAttribute, kAXTitleAttribute, kAXValueAttribute] {
                var value: CFTypeRef?
                if AXUIElementCopyAttributeValue(node, key as CFString, &value) == .success,
                   let text = value as? String, text.contains(label) { return true }
            }
        }
        if depth < 25 {
            var children: CFTypeRef?
            if AXUIElementCopyAttributeValue(node, kAXChildrenAttribute as CFString, &children) == .success,
               let elements = children as? [AXUIElement] {
                pending.append(contentsOf: elements.map { ($0, depth + 1) })
            }
        }
    }
    return false
}

@main
private struct Probe {
    @MainActor
    static func main() async {
        guard AXIsProcessTrusted() else {
            print("{\"error\":\"Accessibility is unavailable; no prompt was requested\"}")
            exit(2)
        }
        guard NSRunningApplication.runningApplications(withBundleIdentifier: "ch.lkmc.foldover").isEmpty else {
            fputs("Foldover is already running; this is not a cold process launch\n", stderr)
            exit(2)
        }
        let started = ProcessInfo.processInfo.systemUptime
        let configuration = NSWorkspace.OpenConfiguration()
        configuration.arguments = ["-foldover-skip-update-check", "YES"]
        configuration.activates = true
        do {
            let launch = Task { @MainActor in
                let app = try await NSWorkspace.shared.openApplication(
                    at: URL(fileURLWithPath: "/Applications/Foldover.app"), configuration: configuration)
                return (app.processIdentifier, ProcessInfo.processInfo.systemUptime - started)
            }
            while ProcessInfo.processInfo.systemUptime - started < 30 {
                if let app = NSRunningApplication.runningApplications(withBundleIdentifier: "ch.lkmc.foldover").first,
                   catalogIsReady(app.processIdentifier, label: "Qualification local million") {
                    let seconds = ProcessInfo.processInfo.systemUptime - started
                    let (_, launchSeconds) = try await launch.value
                    print("{\"pid\":\(app.processIdentifier),\"cached_catalog_seconds\":\(seconds),\"launch_completion_seconds\":\(launchSeconds),\"definition\":\"AX cached catalog content polled concurrently with NSWorkspace launch; warm storage and shared host; includes 2 ms polling and bounded AX traversal; not frame-present latency\"}")
                    return
                }
                try await Task.sleep(for: .milliseconds(2))
            }
            _ = try await launch.value
            fputs("Timed out waiting for cached catalog content\n", stderr)
        } catch {
            fputs("Cold-start probe failed: \(error)\n", stderr)
        }
        exit(1)
    }
}
