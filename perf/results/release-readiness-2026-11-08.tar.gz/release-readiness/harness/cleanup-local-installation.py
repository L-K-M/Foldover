"""Restore the primary host after the sealed, stock qualification artifact is safe."""
from peer_support import *
import ctypes,datetime,hashlib,os,plistlib,re,shutil,signal,time
l=ledger();assert l['app_before']=='absent' and l['app_installed_by_qualification']
configuration=json.loads((BASE/'configuration-cleanup-verification.json').read_text())
assert configuration['cleanup_mode']=='RemoveExclusiveTaskCatalog'
assert configuration['remaining_configuration_contains_only_task_fixture_pin']
assert configuration['remaining_configuration_exclusively_task_owned']
assert configuration['all_remaining_pair_ids_belong_to_task']
assert configuration['public_revocation_qualified'] is False
assert configuration['owned_device_count_left_for_exclusive_catalog_deletion']<=1
rc=json.loads((BASE/'rc/provenance.json').read_text());assert not rc['installed_qualification_pending']
archive=BASE/'rc/Foldover-0.2.0-qualification.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()==rc['archive_sha256']
app=Path('/Applications/Foldover.app');assert str(app)==l['installed_bundle']['path'] and not app.is_symlink()
catalog=Path(l['default_catalog']);assert catalog==Path.home()/'Library/Application Support/Foldover';assert not catalog.is_symlink() and catalog.resolve()==catalog
assert (catalog.stat().st_dev,catalog.stat().st_ino)==(l['catalog_device'],l['catalog_inode']) and (catalog/'.qualification-owner').read_text().strip()==l['uuid']
paths={'app':'Contents/MacOS/Foldover','agent':'Contents/Library/LaunchServices/foldoverd','cli':'Contents/Library/LaunchServices/foldover'}
for role,rel in paths.items():assert hashlib.sha256((app/rel).read_bytes()).hexdigest()==rc['roles'][role]['sha256']==l['installed_bundle']['roles'][role]['sha256']
lib=ctypes.CDLL('/usr/lib/libproc.dylib');lib.proc_pidpath.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32];lib.proc_pidpath.restype=ctypes.c_int

def processes_at(path):
 result=[]
 for row in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines():
  parts=row.strip().split(None,1)
  if len(parts)!=2 or Path(parts[1]).name!=Path(path).name:continue
  pid=int(parts[0]);buf=ctypes.create_string_buffer(4096);n=lib.proc_pidpath(pid,buf,len(buf))
  if n>0 and Path(os.fsdecode(buf.value)).resolve()==Path(path).resolve():result.append(pid)
 return result

# Only our installed GUI and launchd labels are touched. No global resets.
for pid in processes_at(app/paths['app']):os.kill(pid,signal.SIGTERM)
for _ in range(100):
 if not processes_at(app/paths['app']):break
 time.sleep(.1)
else:raise RuntimeError('Owned GUI did not quit')
labels={l['smservice_label']}
for bundle in l.get('previous_installed_bundles',[]):
 cdhash=bundle['roles']['agent']['cdhash'];assert re.fullmatch('[a-f0-9]{40}',cdhash);labels.add('ch.lkmc.foldover.agent.'+cdhash)
for label in labels:
 assert re.fullmatch(r'ch\.lkmc\.foldover\.agent\.[a-f0-9]{40}',label)
 service=f'gui/{os.getuid()}/'+label
 if subprocess.run(['launchctl','print',service],capture_output=True).returncode==0:subprocess.run(['launchctl','bootout',service],capture_output=True,check=True)
for _ in range(100):
 if not processes_at(app/paths['agent']):break
 time.sleep(.1)
else:raise RuntimeError('Owned agent still running; stop any manual supervisor first')

# The original stock archive was sealed first. This replacement is solely
# a cleanup tool and is never represented as a qualified or packaged app.
shutil.copy2(BASE/'cleanup-owned-agent',app/paths['app'])
subprocess.run(['codesign','--force','--sign','-','--options','runtime',str(app)],capture_output=True,check=True)
mutation={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Cleanup-only SMAppService unregister helper; stock artifact sealed before mutation','original_main_sha256':rc['roles']['app']['sha256'],'cleanup_main_sha256':hashlib.sha256((app/paths['app']).read_bytes()).hexdigest()};(BASE/'cleanup-bundle-mutation-private.json').write_text(json.dumps(mutation,indent=2)+'\n')
p=subprocess.run([str(app/paths['app']),l['uuid']],capture_output=True,text=True,timeout=60);(BASE/'sm-unregister-cleanup-private.json').write_text(json.dumps({'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2)+'\n');assert p.returncode==0,p.stderr
r=json.loads(p.stdout);assert r['unregister_error'] is None and r['status_raw_value']==0,r
for label in labels:assert subprocess.run(['launchctl','print',f'gui/{os.getuid()}/'+label],capture_output=True).returncode!=0
assert not processes_at(app/paths['agent']) and not processes_at(app/paths['app'])
shutil.rmtree(app);assert not app.exists()

before=json.loads((BASE/'primary-peer-keychain-before-private.json').read_text());assert before['returncode']==44 and before['existed'] is False and before['secret_read'] is False
if l['primary_peer_identity_created']:
 subprocess.run(['security','delete-generic-password','-s','ch.lkmc.foldover.peer-identity','-a','local-device',str(Path.home()/'Library/Keychains/login.keychain-db')],capture_output=True,check=True,timeout=30)
assert subprocess.run(['security','find-generic-password','-s','ch.lkmc.foldover.peer-identity','-a','local-device',str(Path.home()/'Library/Keychains/login.keychain-db')],capture_output=True,timeout=15).returncode==44
# Our catalog was absent before the atomic claim. Its inode/marker were
# checked above, and its remaining configuration was audited through normal IPC. Every
# remaining pair and its only pin belong to this task; they were
# independently checked against the fixture ledger; public revocation was
# blocked by Keychain access and is not reported as qualified.
assert (catalog/'.qualification-owner').read_text().strip()==l['uuid'];shutil.rmtree(catalog);assert not catalog.exists()
assert l['defaults_existed'];backup=Path(l['defaults_backup']);assert backup.parent==BASE and backup.is_file()
subprocess.run(['defaults','import','ch.lkmc.foldover',str(backup)],capture_output=True,check=True)
restored=subprocess.run(['defaults','export','ch.lkmc.foldover','-'],capture_output=True,check=True);assert plistlib.loads(restored.stdout)==plistlib.loads(backup.read_bytes()),'Preferences did not restore exactly'
root=Path(l['fixture_root']);assert root.parent==Path('/Volumes/PaseoData') and root.name=='foldover-perf-qualification-'+l['uuid'] and not root.is_symlink();assert root.resolve()==root and (root/'.qualification-owner').read_text().strip()==l['uuid'];shutil.rmtree(root);assert not root.exists()
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owned_gui_quit':True,'owned_service_unregistered':True,'owned_jobs_absent':True,'own_installation_removed_originally_absent':True,'own_catalog_removed_originally_absent':True,'own_fixture_pin_removed_with_exclusive_task_catalog':True,'public_peer_revocation_qualified':False,'preexisting_defaults_restored':True,'own_new_peer_keychain_item_removed':True,'owned_local_corpora_removed':True,'stock_archive_preserved':True};(BASE/'local-cleanup-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
