// Qualification cleanup only. Never package this executable in the release artifact.
import Foundation
import ServiceManagement

@main
struct CleanupOwnedAgent {
    @MainActor
    static func main() async {
        let arguments = CommandLine.arguments
        guard arguments.count == 2,
              arguments[1].count == 32,
              arguments[1].allSatisfy({ $0.isHexDigit }),
              Bundle.main.bundleIdentifier == "ch.lkmc.foldover",
              Bundle.main.bundleURL.path == "/Applications/Foldover.app" else {
            print("Refusing cleanup outside the owned qualification app")
            exit(2)
        }
        let marker = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Application Support/Foldover/.qualification-owner")
        guard let owner = try? String(contentsOf: marker, encoding: .utf8),
              owner.trimmingCharacters(in: .whitespacesAndNewlines) == arguments[1] else {
            print("Refusing cleanup without the matching catalog ownership marker")
            exit(2)
        }
        let service = SMAppService.agent(plistName: "ch.lkmc.foldover.agent.plist")
        let error: String? = await withCheckedContinuation { continuation in
            service.unregister { @Sendable error in
                continuation.resume(returning: error?.localizedDescription)
            }
        }
        let result: [String: Any] = ["unregister_error": error ?? NSNull(),
                                      "status_raw_value": service.status.rawValue]
        do {
            let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
            FileHandle.standardOutput.write(data)
            FileHandle.standardOutput.write(Data([10]))
        } catch {
            print("Cleanup result could not be encoded")
            exit(1)
        }
        exit(error == nil ? 0 : 1)
    }
}
