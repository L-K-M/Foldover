"""Clear only the catalog entries created by this qualification, before stopping its agent."""
from peer_support import *
import datetime,hashlib
l=ledger();catalog=Path(l['default_catalog']);assert (catalog/'.qualification-owner').read_text().strip()==l['uuid']
assert (catalog.stat().st_dev,catalog.stat().st_ino)==(l['catalog_device'],l['catalog_inode'])
assert (BASE/'sftp-cancel-fixed-verification.json').exists()
CLI='/Applications/Foldover.app/Contents/Library/LaunchServices/foldover'
assert hashlib.sha256(Path(CLI).read_bytes()).hexdigest()==l['installed_bundle']['roles']['cli']['sha256']
def run(args):return subprocess.run([CLI,*args],capture_output=True,text=True,timeout=120,check=True).stdout
assert not any(x.strip().startswith(CLI+' sync ') for x in subprocess.check_output(['ps','-axo','command='],text=True).splitlines()), 'A sync client is still active'
pairs=[json.loads(x) for x in run(['pairs']).splitlines() if x.strip()];expected={x['id'] for x in l['owned_pairs'].values()};assert {x['id'] for x in pairs}==expected,'Unexpected catalog pair; refusing cleanup'
assert not run(['shares']).strip(),'Unexpected offered share; refusing cleanup'
peers=json.loads(run(['peers']));allowed={l['remote_peer_fixture']['device']};assert all(x['device'] in allowed for x in peers['devices']+peers['pending']),'Unexpected peer identity; refusing cleanup'
blocked=json.loads((BASE/'peer-keychain-authorization-verification.json').read_text())
assert blocked['exact_task_created_item_only'] and blocked['identity_replaced'] is False
assert blocked['fresh_manually_launched_process_reopen_succeeded'] is False
assert not peers['pending'],'Unexpected pending pairing; refuse cleanup'
# The current agent cannot initialize its peer identity. Do not bypass that
# failure or call catalog deletion a successful public revocation. This
# catalog was absent before the task and its only pin is the task fixture's.
assert peers['device'] is None,'A live peer link needs ordinary revocation first'
owned_device_count=len(peers['devices'])
for pair in pairs:run(['pairs','remove',pair['id'],str(pair['revision'])])
assert not run(['pairs']).strip() and not run(['shares']).strip();after=json.loads(run(['peers']));assert after['devices']==peers['devices'] and not after['pending']
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed_owned_pair_count':len(pairs),'owned_device_count_left_for_exclusive_catalog_deletion':owned_device_count,'offered_shares_empty':True,'catalog_configuration_empty':False,'cleanup_mode':'RemoveExclusiveTaskCatalog','remaining_configuration_contains_only_task_fixture_pin':True,'public_revocation_qualified':False,'reason':'Current peer identity remains unavailable; the originally absent, marker/inode-verified task catalog will be removed during cleanup. No direct database mutation or authentication bypass.'};(BASE/'configuration-cleanup-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
