"""Use after the Unlisted control has paired but ordinary share lookup failed."""
from peer_support import *
import datetime,hashlib,time
CLI='/Applications/Foldover.app/Contents/Library/LaunchServices/foldover'
f=ledger()['remote_peer_fixture'];primary=json.loads(subprocess.run([CLI,'peers'],capture_output=True,text=True,check=True).stdout)
assert any(x['device']==f['device'] for x in primary['devices']);assert json.loads(remote_file('control/status.json'))['paired']
before=subprocess.run([CLI,'peers','shares',f['device']],capture_output=True,text=True,timeout=40);assert before.returncode!=0 and 'not on this network' in before.stderr.lower(),before.stderr
assert not any(x['device']==f['device'] for x in primary['nearby'])
write_remote('control/stop',b'qualification fixture discovery correction\n')
for _ in range(100):
 if json.loads(remote_file('control/status.json'))['shutdown']:break
 time.sleep(.1)
else:raise RuntimeError('Unlisted control did not stop')
# Retain the exact negative-control binary until the owned root is cleaned.
remote_script('set -eu\n'+shlex.join(['cp',f['root']+'/control/peer_qualification',f['root']+'/control/peer_qualification-unlisted-control'])+'\n')
p=BASE.parent/'cargo-qual-root/release/examples/peer_qualification';data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();write_remote('control/peer_qualification',data,'700');assert remote_script('shasum -a 256 '+shlex.quote(f['root']+'/control/peer_qualification')).split()[0]==sha
patch=(BASE/'peer-discovery.patch').read_bytes();l=ledger();f=l['remote_peer_fixture'];f.update(previous_unlisted_binary_sha256=f['binary_sha256'],binary_sha256=sha,source_base_commit='8fe4c1d2a7b1cb8446d7c0507630cb921784e883',source_patch_sha256=hashlib.sha256(patch).hexdigest(),presence='Announced');l['remote_peer_fixture']=f;(BASE/'installed-fixture-private.json').write_text(json.dumps(l,indent=2)+'\n')
subprocess.run(['python3',str(BASE/'restart-peer-fixture.py')],check=True)
for _ in range(100):
 primary=json.loads(subprocess.run([CLI,'peers'],capture_output=True,text=True,check=True).stdout)
 if any(x['device']==f['device'] for x in primary['nearby']):break
 time.sleep(.2)
else:raise RuntimeError('Announced fixture was not discovered')
after=subprocess.run([CLI,'peers','shares',f['device']],capture_output=True,text=True,timeout=40);assert after.returncode==0,after.stderr
shares=json.loads(after.stdout);assert shares['shares']==[{'id':f['share_id'],'name':'Qualification Share'}],shares
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'unlisted_control_was_normally_paired':True,'unlisted_control_not_nearby':True,'unlisted_control_share_lookup_failed':True,'same_identity_pin_and_transport_port_retained':True,'announced_fixture_discovered':True,'announced_fixture_share_lookup_succeeded':True,'scope':'Same stock manually launched primary agent and normal authenticated CLI; only the test fixture changed from Unlisted to Announced. No production app/network/privacy settings changed.'};(BASE/'peer-discovery-regression-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
