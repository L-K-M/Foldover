"""Export an explicit whitelist; never copy private state, keys, GUI captures or packet traces."""
from pathlib import Path
import csv,gzip,hashlib,io,json,re,tarfile,datetime,socket
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
PUBLIC=ROOT/'perf/results'
l=json.loads((BASE/'installed-fixture-private.json').read_text())
replacements={str(ROOT):'<WORKTREE>',l['fixture_root']:'<LOCAL_FIXTURE>',l['default_catalog']:'<OWNED_DEFAULT_CATALOG>',l['nas_root']:'<NAS_FIXTURE>',l['nas_root'].rsplit('/',1)[0]:'<NAS_PARENT>',l['nas_target']:'<NAS_USER>@<NAS_HOST>',l['nas_target'].split('@')[-1]:'<NAS_HOST>',l['uuid']:'<FIXTURE_UUID>','<USER_HOME>':'<USER_HOME>'}
f=l.get('remote_peer_fixture',{})
for k,alias in [('root','<PEER_FIXTURE>'),('renamed_from','<OLD_PEER_FIXTURE>'),('target','<PEER_USER>@<PEER_HOST>'),('lan_ipv4','<PEER_IP>'),('owner','<PEER_OWNER_UUID>')]:
 if f.get(k):replacements[f[k]]=alias
if f.get('target'):replacements[f['target'].split('@')[-1]]='<PEER_HOST>'
replacements[str(Path.home())]='<USER_HOME>'
replacements[str(ROOT.parents[3])]='<PASEO_HOME>'
if f.get('target'):replacements[f['target'].split('@')[-1].split('.')[0]]='<PEER_HOST>'
replacements[socket.gethostname()]='<PRIMARY_HOST>'
replacements[socket.gethostname().split('.')[0]]='<PRIMARY_HOST>'
# Retain actual run tokens privately, but remove their exact values from
# raw logs too. Hashes and public ephemeral device identifiers are evidence.
review_tokens=set()
for summary in BASE.glob('installed-*/summary.json'):
 value=json.loads(summary.read_text());args=value.get('arguments',[])
 for index,arg in enumerate(args[:-1]):
  if arg=='--review':review_tokens.add(args[index+1])
 token=value.get('status',{}).get('preview',{}).get('review_token')
 if token:review_tokens.add(token)
for token in review_tokens:replacements[token]='<REVIEW_TOKEN>'
ordered=sorted(replacements,key=len,reverse=True)
def clean_string(s):
 for x in ordered:s=s.replace(x,replacements[x])
 s=re.sub(r'(?<![0-9])(?:10\.[0-9]+\.[0-9]+\.[0-9]+|192\.168\.[0-9]+\.[0-9]+|172\.(?:1[6-9]|2[0-9]|3[01])\.[0-9]+\.[0-9]+)(?![0-9])','<LAN_IP>',s)
 s=s.replace('<PRIMARY_HOST>','<PRIMARY_HOST>').replace('<PEER_HOST>','<PEER_HOST>')
 s=re.sub(r'(--review(?:=|[\s\x27\x22,]+))[a-fA-F0-9]{64}',r'\1<REVIEW_TOKEN>',s)
 return s
SECRET_KEYS={'reviewtoken','privatekeypath','knownhostspath','password','identity','code','authorization','token','secret','apikey','privatekey','sshkey','passphrase'}
def clean(v,key=''):
 if re.sub('[^a-z0-9]','',key.lower()) in SECRET_KEYS:return '<REDACTED>'
 if isinstance(v,dict):return {k:clean(x,k) for k,x in v.items()}
 if isinstance(v,list):
  if v and all(type(x) is int and 0<=x<=255 for x in v):
   try:
    s=bytes(v).decode()
    if s.isprintable():return clean_string(s)
   except UnicodeDecodeError:pass
  if key in {'arguments','argv','args'}:
   out=[];redact=False
   for x in v:
    out.append('<REVIEW_TOKEN>' if redact else clean(x));redact=x=='--review'
   return out
  return [clean(x) for x in v]
 if isinstance(v,str):return clean_string(v)
 return v
payload={}
def add_json(path,value):payload[path]=(json.dumps(clean(value),indent=2,ensure_ascii=False)+'\n').encode()
def add_text(path,value):
 if path.endswith('.jsonl'):
  payload[path]=''.join(json.dumps(clean(json.loads(line)),ensure_ascii=False)+'\n' for line in value.splitlines() if line.strip()).encode()
 else:payload[path]=clean_string(value).encode()
rows=[]
for d in sorted(BASE.glob('installed-*')):
 p=d/'summary.json'
 if not d.is_dir() or not p.exists():continue
 s=json.loads(p.read_text());add_json('cases/'+d.name+'/summary.json',s)
 for name in ['status-latency.jsonl','stderr.txt','resources.txt','interpretation.json','intentional-stop.json']:
  p=d/name
  if not p.exists():continue
  if p.suffix=='.json':add_json('cases/'+d.name+'/'+name,json.loads(p.read_text()))
  else:add_text('cases/'+d.name+'/'+name,p.read_text())
 v=s.get('status',{});result=v.get('result',{});counts=v.get('preview',{}).get('counts',{})
 rows.append({'case':d.name,'revision':s.get('revision',''),'returncode':s.get('returncode',''),'state':v.get('state','session'),'elapsed_seconds':s.get('elapsed_seconds',''),'failure_count':result.get('failure_count',''),'cancelled':result.get('cancelled',''),'copies':result.get('copied',counts.get('copies','')),'updates':result.get('updated',counts.get('updates','')),'archives':result.get('archived',counts.get('archives','')),'blocked':counts.get('blocked',''),'conflicts':result.get('conflicts',counts.get('conflicts','')),'max_cli_status_seconds':s.get('max_status_latency_seconds','')})
FACTS=['defaults-restore-verification.json', 'configuration-cleanup-ordering-error.json', 'owned-terminal-window-verification.json', 'pr274-ci-retry.json', 'peer-oracle-environment-verification.json', 'peer-fault-initial-stop-verification.json', 'peer-fault-drained2-stage-observation.json', 'peer-fault-drained2-kept-observation.json', 'peer-fault-drained2-verification.json', 'lease-cancel-fixed-verification.json', 'final-installed-sm-runtime-verification.json', 'peer-keychain-authorization-verification.json', 'desktop-cleanup-verification.json', 'ci-lease-followup-qualification.json', 'peer-discovery-regression-verification.json', 'nas-agent-sm-lifecycle-verification.json', 'rc-latest-source-rebuild-verification.json', 'final-installed-bundle-verification.json', 'final-local1m-memory.json', 'peer-primary-manual-context-verification.json', 'peer-final-sm-context-verification.json', 'peer-revocation-verification.json', 'configuration-cleanup-verification.json', 'local-cleanup-verification.json', 'remote-cleanup-verification.json', 'ci-final-qualification.json', 'nas1m-warm-tracked-verification.json', 'sftp-cancel-fixed-verification.json', 'peer-small-verification.json', 'peer-fault-verification.json', 'peer-unoffered-share-refusal.json', 'peer-existing-account-preserved-verification.json', 'nas1m-baseline-tracked-verification.json', 'host-provenance.json', 'installed-local1m-warm-memory.json', 'deep-metadata-fixture.json', 'deep-metadata-independent-verification.json', 'deep-metadata-recovery-verification.json', 'multiple-held-previews-verification.json', 'large-sftp-verification.json', 'sftp-cancel-resume-verification.json', 'sftp-mid-copy-stage-observation.json', 'nas-metadata-source-provenance.json', 'nas-metadata-independent-verification.json', 'app-cold-start-initial-criterion-results.json', 'app-cold-start-awaiting-launch-results.json', 'app-cold-start-results.json', 'app-launch-instruments-interpretation.json', 'peer-quic-primary-diagnostic-summary.json', 'peer-udp-probe-result.json', 'build-cache-cleanup-verification.json']
for name in FACTS:
 p=BASE/name
 if p.exists():add_json('observations/'+name,json.loads(p.read_text()))
LOGS=['pr274-archive-simulation-recheck.log', 'app-final-source.patch', 'peer-fixture-final.patch', 'peer-shutdown-regression-before.log', 'peer-shutdown-regression-after.log', 'peer-shutdown-server-before.log', 'lease-cancellation-regression-before.log', 'lease-cancellation-regression-after.log', 'peer-discovery-validation.log', 'peer-discovery.patch', 'native-ci.log', 'device-matrix.log', 'fd-policy-parent-before-v3.log', 'fd-policy-parent-after.log', 'cancellation-regression-before.log', 'cancellation-inflight-before.log', 'cancellation-native-tests-final.log', 'cancellation-clippy-final.log', 'cancellation-review-final-tests.log', 'cancellation-review-final-clippy.log', 'peer-fixture-missing-state-before.log', 'peer-fixture-parent-validation.log', 'agent-plist-tests.log', 'tracked-final-docs.log', 'release-results-docs.log', 'release-results-mermaid.log']
for name in LOGS:
 p=BASE/name
 if p.exists():add_text('checks/'+name,p.read_text())
for name in ['installed-run-case.py','supervise-installed-agent.py','supervise-installed-agent-current.py','peer-small-workflow.py','peer-fault-workflow.py','peer_small_support.py','peer_support.py','enable-peer-discovery.py','installed-sftp-cancel-fixed.py','installed-sftp-cancel-observed.py','installed-lease-cancel-fixed.py','peer-fault-drained2-workflow.py','restart-peer-fixture.py','cached-view-probe.swift','verify-deep-metadata.py','export-public-evidence.py','finish-final-memory.py','audit-owned-configuration-cleanup.py','resume-final-memory-after-audit.py','clear-owned-configuration.py','cleanup-owned-agent.swift','cleanup-local-installation.py','resume-local-cleanup.py']:
 add_text('harness/'+name,(BASE/name).read_text())
bundles=[]
for x in [*l.get('previous_installed_bundles',[]),l['installed_bundle']]:
 # Ledger history stores complete installed bundle entries, never catalog paths.
 bundles.append({k:x[k] for k in ['version','source_revision','roles'] if k in x})
add_json('provenance/installed-bundles.json',bundles)
add_json('provenance/peer-fixture.json',{k:f[k] for k in ['binary_sha256','source_revision','source_base_commit','source_patch_sha256','previous_unlisted_binary_sha256','presence','shutdown_drain','previous_undrained_binary_sha256','previous_discovery_patch_sha256','source_patch_file'] if k in f})
add_json('provenance/qualification-artifact.json',json.loads((BASE/'rc/provenance.json').read_text()))
add_json('provenance/scope.json',{'schema':1,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':len(rows),'missing_whitelisted_facts':[name for name in FACTS if not (BASE/name).exists()],'missing_whitelisted_logs':[name for name in LOGS if not (BASE/name).exists()],'missing_fact_notes':{'peer-revocation-verification.json':'Public revocation remains unqualified because peer identity initialization failed.','peer-fault-verification.json':'Superseded planned filename; retain the initial failed-stop observation and successful drained2 observation separately.'},'unfinished_case_directories_without_summary':[p.name for p in BASE.glob('installed-*') if p.is_dir() and ((p/'stdout.json').exists() or (p/'agent.stdout').exists()) and not (p/'summary.json').exists()],'path_arrays':'Printable UTF-8 byte paths are exported as redacted strings. Review tokens are removed.','scope':'Real unmodified installed Release binaries, normal default owned catalog. Sessions started manually for kernel RSS are separately labelled; SMAppService runs are distinct. Shared host and warm OS caches; no idle, cold-storage or wired 1GbE claim. Failed/cancelled runs remain failures/cancellations.','excluded':'Private catalogs, identity keys, SSH configuration, public-key installation details, raw GUI captures, network packet captures and owner-specific network settings.'})
stream=io.StringIO();w=csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);payload['index.csv']=stream.getvalue().encode()
# Fail closed if any selected raw file unexpectedly contains private identifiers or a key.
for name,data in payload.items():
 s=data.decode()
 for token in [str(ROOT),l['fixture_root'],l['default_catalog'],l['nas_root'],l['uuid'],'<USER_HOME>',l['nas_target'].split('@')[-1],f.get('owner',''),f.get('lan_ipv4',''),f.get('root','')]:
  if token and token in s:raise ValueError('Private identifier remains in '+name)
 if re.search(r'BEGIN (?:OPENSSH |RSA |EC |)?PRIVATE KEY',s):raise ValueError('Private key found in '+name)
 if re.search(r'/Users/(?!Shared/)[A-Za-z0-9._-]+|[\w.+-]+@[\w.-]+\.(?:com|net|local)',s):raise ValueError('Unexpected private home/account identifier in '+name)
 for token in review_tokens:
  if token in s:raise ValueError('Unredacted review token in '+name)
manifest={'schema':1,'files':[{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(payload.items())]};add_json('manifest.json',manifest)
PUBLIC.mkdir(exist_ok=True);archive=PUBLIC/'release-readiness-2026-11-08.tar.gz'
with archive.open('wb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,data in sorted(payload.items()):
  entry=tarfile.TarInfo('release-readiness/'+name);entry.size=len(data);entry.mode=0o644;entry.uid=entry.gid=0;entry.uname=entry.gname='';entry.mtime=0;tar.addfile(entry,io.BytesIO(data))
(PUBLIC/'release-readiness-index.csv').write_bytes(payload['index.csv']);(PUBLIC/'release-readiness-manifest.json').write_bytes(payload['manifest.json']);print(json.dumps({'cases':len(rows),'files':len(payload),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive':str(archive)}),flush=True)
