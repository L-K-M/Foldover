from peer_support import *
import datetime,ctypes,os,signal,time,re,sys
l=ledger();case='installed-final-local1m-warm-preview';pair=l['owned_pairs']['local-million']['id']
subprocess.run([sys.executable,str(BASE/'installed-run-case.py'),case,'sync',pair,'--preview'],check=True)
s=json.loads((BASE/case/'summary.json').read_text());assert s['returncode']==0 and not s['polling_errors'];v=s['status'];assert v['state']=='previewed'
assert all(v['preview']['counts'][k]==0 for k in ['copies','updates','moves','archives','conflicts','blocked']),v['preview']['counts']
# Clear only task-created configuration while the real authenticated agent
# is still available. This does not claim blocked peer revocation succeeded.
subprocess.run([sys.executable,str(BASE/'clear-owned-configuration.py')],check=True)
app='/Applications/Foldover.app/Contents/MacOS/Foldover';lib=ctypes.CDLL('/usr/lib/libproc.dylib');lib.proc_pidpath.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32];lib.proc_pidpath.restype=ctypes.c_int
for row in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines():
 fields=row.strip().split(None,1)
 if len(fields)!=2 or fields[1]!=app:continue
 pid=int(fields[0]);buf=ctypes.create_string_buffer(4096);assert lib.proc_pidpath(pid,buf,len(buf))>0 and os.fsdecode(buf.value)==app;os.kill(pid,signal.SIGTERM)
for _ in range(100):
 if not any(row.strip().endswith(app) for row in subprocess.check_output(['ps','-axo','pid=,comm='],text=True).splitlines()):break
 time.sleep(.1)
else:raise RuntimeError('Own GUI did not quit')
out=BASE/'installed-agent-final-local1m-session';(out/'STOP').write_text('final memory and owned configuration checks complete\n')
for _ in range(100):
 if (out/'summary.json').exists():break
 time.sleep(.2)
else:raise RuntimeError('Timed agent has not stopped')
summary=json.loads((out/'summary.json').read_text());assert summary['returncode']==0 and not summary['errors'],summary
text=(out/'resources.txt').read_text();matches=re.findall(r'^\s*(\d+)\s+maximum resident set size\s*$',text,re.M);assert len(matches)==1;peak=int(matches[0])
samples=[json.loads(x) for x in (out/'samples.jsonl').read_text().splitlines() if x.strip()];assert any('app_rss_kib' in x for x in samples),'GUI was never observed'
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_build_label':l['revision'],'production_equivalent_code_commit':'4f1490b7dc9b9370bc3b125614a35c47871d3696','peak_rss_bytes':peak,'budget_bytes':500000000,'budget_pass':peak<500000000,'preview_seconds':s['elapsed_seconds'],'max_cli_status_seconds':s['max_status_latency_seconds'],'zero_change_full_manual_preview':True,'stock_gui_observed_in_process_samples':True,'scope':'Fresh manually timed current installed stock agent and real GUI, normal default owned catalog/authentication. One active local-million pair; other pairs idle. Keychain peer initialization failed, so no peer link ran. Warm shared host; separate SMAppService lifecycle evidence. Kernel peak includes the subsequent owned-configuration cleanup.'};(BASE/'final-local1m-memory.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
