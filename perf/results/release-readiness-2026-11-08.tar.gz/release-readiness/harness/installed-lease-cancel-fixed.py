from peer_small_support import *
import datetime,hashlib,sqlite3
l=ledger();f=json.loads((BASE/'lease-cancel-fixture-private.json').read_text());left=Path(f['left']);right=Path(f['right']);assert hashlib.sha256((right/'.foldover/lock').read_bytes()).hexdigest()==f['lock_sha256']
pair=json.loads(local(['pairs','add','Qualification lease cancellation',str(left),str(right),'mirror-left','--times','ignore','--attributes','ignore','--permissions','ignore','--schedule','manual','--review','required']));l=ledger();l['owned_pairs']['lease-cancel']=pair;(BASE/'installed-fixture-private.json').write_text(json.dumps(l,indent=2)+'\n')
p=case('installed-lease-cancel-fixed-preview',pair['id'],'--preview');assert p['state']=='previewed' and p['preview']['counts']['copies']==1,p
v=p['preview'];runner=None;observed=None
try:
 with (BASE/'lease-cancel-fixed-runner.log').open('x') as log:
  runner=subprocess.Popen([sys.executable,str(BASE/'installed-run-case.py'),'installed-lease-cancel-fixed','sync',pair['id'],'--approve',str(v['left']['deletions']),str(v['right']['deletions']),'--review',v['review_token'],'--progress'],stdout=log,stderr=subprocess.STDOUT)
  deadline=time.monotonic()+30
  while runner.poll() is None and time.monotonic()<deadline:
   data=BASE/'installed-lease-cancel-fixed/stdout.json'
   if data.exists():
    for line in data.read_text().splitlines():
     try:row=json.loads(line)
     except json.JSONDecodeError:continue
     if row.get('state')=='working' and row['progress'].get('waiting_for')==f['waiting_label']:observed=row
   if observed:break
   time.sleep(.1)
  assert observed,'The run never reported waiting for the synthetic holder'
  t=time.monotonic();cancel=subprocess.run([CLI,'sync',pair['id'],'--cancel'],capture_output=True,text=True,timeout=30);seconds=time.monotonic()-t;rc=runner.wait(timeout=30)
 assert cancel.returncode==0,cancel.stderr
 status=json.loads(cancel.stdout.splitlines()[-1]);assert status['state']=='finished' and status['result']['cancelled'] and not status['result']['failure_count'],status
 assert rc==1,rc
 assert hashlib.sha256((right/'.foldover/lock').read_bytes()).hexdigest()==f['lock_sha256']
 assert not (right/'source.dat').exists() and hashlib.sha256((left/'source.dat').read_bytes()).hexdigest()==f['source_sha256']
 with sqlite3.connect(Path(l['default_catalog']).joinpath('state.db').as_uri()+'?mode=ro',uri=True) as db:
  key=bytes.fromhex(pair['id']);count=db.execute('SELECT count(*) FROM base_entry WHERE pair_id=?',(key,)).fetchone()[0];ids=db.execute('SELECT left_identity,right_identity FROM pair WHERE id=?',(key,)).fetchone()
 assert count==0 and ids==(None,None),(count,ids)
 r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observed_synthetic_holder_before_cancel':True,'cancel_seconds':seconds,'cancel_command_exit':cancel.returncode,'original_run_exit':rc,'cancelled_true_without_false_failure':True,'foreign_synthetic_lock_bytes_unchanged':True,'no_target_data_published':True,'source_hash_unchanged':True,'base_entries':count,'first_sync_identities_uncommitted':True,'scope':'Final stock Release candidate under normal SMAppService, authenticated CLI/default owned catalog. A fresh local test pair held a synthetic lease; no real lease file or production timing was modified.'};(BASE/'lease-cancel-fixed-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
finally:
 if runner is not None and runner.poll() is None:
  subprocess.run([CLI,'sync',pair['id'],'--cancel'],capture_output=True,text=True,timeout=30);runner.wait(timeout=30)
