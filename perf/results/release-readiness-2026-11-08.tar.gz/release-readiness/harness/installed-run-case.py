"""Retain real installed CLI results and independent status latency samples."""
from pathlib import Path
import datetime,hashlib,json,re,subprocess,sys,threading,time
w=Path(__file__).resolve().parent;r=json.loads((w/'installed-fixture-private.json').read_text());label=sys.argv[1];args=sys.argv[2:]
assert re.fullmatch('[a-z0-9-]+',label)
assert args[:1]==['sync'] and args[1] in {p['id'] for p in r['owned_pairs'].values()}
assert (Path(r['default_catalog'])/'.qualification-owner').read_text().strip()==r['uuid']
cli=Path(r['installed_bundle']['path'])/'Contents/Library/LaunchServices/foldover';assert hashlib.sha256(cli.read_bytes()).hexdigest()==r['installed_bundle']['roles']['cli']['sha256']
out=w/label;out.mkdir();stop=threading.Event();polls=[];errors=[]
def poll():
 with (out/'status-latency.jsonl').open('x') as log:
  while not stop.is_set():
   t=time.monotonic()
   try:
    p=subprocess.run([str(cli),'status'],capture_output=True,text=True,timeout=15);row={'seconds':time.monotonic()-t,'returncode':p.returncode}
    if p.returncode:errors.append(p.stderr)
   except Exception as e:row={'seconds':time.monotonic()-t,'error':repr(e)};errors.append(repr(e))
   polls.append(row);log.write(json.dumps(row)+'\n');log.flush();stop.wait(2)
thread=threading.Thread(target=poll);thread.start();t=time.monotonic();summary={'label':label,'arguments':args,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'revision':r['revision']}
try:
 with (out/'stdout.json').open('x') as stdout,(out/'stderr.txt').open('x') as stderr:
  p=subprocess.run([str(cli),*args],stdout=stdout,stderr=stderr,timeout=14400)
 summary['returncode']=p.returncode
 try:summary['status']=json.loads((out/'stdout.json').read_text().splitlines()[-1])
 except Exception as e:summary['parse_error']=repr(e)
except BaseException as e:summary.update(returncode=1,error=repr(e));raise
finally:
 stop.set();thread.join(timeout=20);summary.update(elapsed_seconds=time.monotonic()-t,status_polls=len(polls),max_status_latency_seconds=max((p['seconds'] for p in polls),default=None),polling_errors=errors);(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({key:summary.get(key) for key in ['label','returncode','elapsed_seconds','max_status_latency_seconds','error','parse_error']}),flush=True)
raise SystemExit(summary['returncode'])
