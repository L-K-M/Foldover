"""Retest the installed cancellation fix using independently observed staging bytes."""
from pathlib import Path
import datetime,hashlib,json,os,shlex,subprocess,sys,time
BASE=Path(__file__).resolve().parent
LEDGER=BASE/'installed-fixture-private.json'
l=json.loads(LEDGER.read_text());root=Path(l['fixture_root'])
assert (root/'.qualification-owner').read_text().strip()==l['uuid']
provenance=json.loads((BASE/'rc/provenance.json').read_text())
assert l['installed_bundle']['roles']['agent']['sha256']==provenance['roles']['agent']['sha256'], 'Install the fixed, archived candidate first'
CLI='/Applications/Foldover.app/Contents/Library/LaunchServices/foldover'
a=l['owned_pairs']['large-sftp'];source=Path(bytes(a['configuration']['left_root']).decode())
name='cancel-fixed.dat';remote_dir=l['nas_root']+'/large-sftp-target';remote=remote_dir+'/'+name

def command(args,timeout=120):
 return subprocess.run([CLI,*args],capture_output=True,text=True,timeout=timeout)

def bandwidth(value):
 global a
 c=a['configuration'];p=command(['pairs','update',a['id'],str(a['revision']),c['name'],bytes(c['left_root']).decode(),bytes(c['right_root']).decode(),'mirror-left','--bandwidth-limit',value]);assert p.returncode==0,p.stderr
 a=json.loads(p.stdout);state=json.loads(LEDGER.read_text());state['owned_pairs']['large-sftp']=a;LEDGER.write_text(json.dumps(state,indent=2)+'\n')

def observe():
 code='import json,os; d='+repr(remote_dir)+'; print(json.dumps({"final_exists":os.path.lexists(d+"/'+name+'"),"staged":{n:os.stat(d+"/"+n).st_size for n in os.listdir(d) if n.startswith(".foldover-tmp-")}}))'
 script='set -eu\n'+f'test "$(cat {shlex.quote(l["nas_root"]+"/.qualification-owner")})" = {shlex.quote(l["uuid"])}\n'+shlex.join(['python3','-c',code])+'\n'
 p=subprocess.run(['ssh','-T','-oControlMaster=no','-oControlPath=none','-oServerAliveInterval=5','-oServerAliveCountMax=2','-oBatchMode=yes','-oConnectTimeout=10',l['nas_target'],'sh','-s'],input=script,capture_output=True,text=True,timeout=20,check=True)
 return json.loads(p.stdout)

before=observe();assert not before['final_exists'] and not before['staged'],before
assert (source/name).exists() and hashlib.sha256((source/name).read_bytes()).digest()==hashlib.sha256((root/'wire-upload.bin').read_bytes()).digest(), 'Reuse only the unchanged source from the cancelled control attempt'
runner=None;observation=None;cancel=None;runner_exit=None
try:
 bandwidth('1')
 with (BASE/'sftp-cancel-observed-runner.log').open('x') as log:
  runner=subprocess.Popen([sys.executable,str(BASE/'installed-run-case.py'),'installed-sftp-cancel-observed','sync',a['id'],'--progress'],stdout=log,stderr=subprocess.STDOUT)
  deadline=time.monotonic()+120
  while runner.poll() is None and time.monotonic()<deadline:
   observation=observe()
   if max(observation['staged'].values(),default=0)>=8*1024*1024:break
   time.sleep(.5)
  t=time.monotonic();cancel=command(['sync',a['id'],'--cancel']);cancel_seconds=time.monotonic()-t
  runner_exit=runner.wait(timeout=30)
 assert observation and max(observation['staged'].values(),default=0)>=8*1024*1024,observation
 v=json.loads(cancel.stdout.splitlines()[-1]);assert cancel.returncode==0 and v['state']=='finished' and v['result']['cancelled'] and v['result']['failure_count']==0,v
 assert runner_exit!=0,'Interrupted run reported success'
 s=json.loads((BASE/'installed-sftp-cancel-observed/summary.json').read_text());assert s['status']['result']['cancelled'] and not s['status']['result']['failure_count'],s
 after=observe();assert not after['final_exists'] and not after['staged'],after
finally:
 if runner is not None and runner.poll() is None:
  command(['sync',a['id'],'--cancel']);runner.wait(timeout=30)
 bandwidth('none')

subprocess.run([sys.executable,str(BASE/'installed-run-case.py'),'installed-sftp-cancel-observed-retry','sync',a['id']],check=True)
s=json.loads((BASE/'installed-sftp-cancel-observed-retry/summary.json').read_text());v=s['status'];assert v['state']=='finished' and not v['result']['cancelled'] and not v['result']['failure_count'] and v['result']['copied']==1,v
p=subprocess.run(['ssh','-T','-oControlMaster=no','-oControlPath=none','-oServerAliveInterval=5','-oServerAliveCountMax=2','-oBatchMode=yes',l['nas_target'],'sha256sum',shlex.quote(remote)],capture_output=True,text=True,check=True)
assert p.stdout.split()[0]==hashlib.sha256((source/name).read_bytes()).hexdigest()
result={'case':'installed-sftp-cancel-observed','previous_attempt_control_observation_timed_out':True,'control_ssh_multiplexing':'Disabled only for independent SSH oracle; production SFTP driver/configuration unchanged','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'installed_agent_sha256':l['installed_bundle']['roles']['agent']['sha256'],'staged_bytes_observed':max(observation['staged'].values()),'cancel_seconds':cancel_seconds,'cancel_command_exit':cancel.returncode,'original_run_exit':runner_exit,'cancelled_true_without_false_failure':True,'no_final_target_after_cancel':True,'staging_removed':True,'ordinary_retry_hash_matches':True,'retry_seconds':s['elapsed_seconds'],'scope':'Stock archived Release candidate, normal SMAppService lifecycle, default owned catalog and authenticated CLI. Only this synthetic pair was throttled. SFTP upload retries restart the file.'}
(BASE/'sftp-cancel-fixed-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
