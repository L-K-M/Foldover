"""Run only after peer-small-workflow passed. Interrupt only our isolated remote fixture."""
from peer_small_support import *
import datetime,hashlib,os,sys,time
l=ledger();f=l['remote_peer_fixture'];a=l['owned_pairs']['peer-small'];root=Path(l['fixture_root']);assert (root/'.qualification-owner').read_text().strip()==l['uuid']
left=Path(bytes(a['configuration']['left_root']).decode());name='fault-transfer.dat';source=left/name;assert not source.exists();source.write_bytes(hashlib.shake_256(b'foldover peer interrupt qualification').digest(64*1024*1024));os.chmod(source,0o640)

def bandwidth(value):
 global a
 c=a['configuration'];a=json.loads(local(['pairs','update',a['id'],str(a['revision']),c['name'],str(left),bytes(c['right_root']).decode(),'sync','--bandwidth-limit',value]));x=ledger();x['owned_pairs']['peer-small']=a;(BASE/'installed-fixture-private.json').write_text(json.dumps(x,indent=2)+'\n')

def remote_observation():
 code='import json,os; root='+repr(f['root']+'/shared')+'; files={};\nfor d,ds,ns in os.walk(root):\n for n in ns:\n  p=os.path.join(d,n)\n  if n.startswith(".foldover-tmp-") or "/.foldover/partial/" in p: files[os.path.relpath(p,root)]=os.stat(p).st_size\nprint(json.dumps({"final_exists":os.path.lexists(os.path.join(root,'+repr(name)+')),"files":files}))'
 return json.loads(remote_script(shlex.join(['/usr/bin/python3','-c',code])))

before=remote_observation();assert not before['files'] and not before['final_exists'],before
bandwidth('4')
p=case('installed-peer-fault-preview',a['id'],'--preview');assert p['state']=='previewed' and p['preview']['counts']['copies']==1 and p['preview']['counts']['conflicts']==p['preview']['counts']['blocked']==0,p
v=p['preview'];runner=None;stopped=False
try:
 with (BASE/'peer-fault-runner.log').open('x') as log:
  runner=subprocess.Popen([sys.executable,str(BASE/'installed-run-case.py'),'installed-peer-fault-interrupted','sync',a['id'],'--approve',str(v['left']['deletions']),str(v['right']['deletions']),'--review',v['review_token'],'--progress'],stdout=log,stderr=subprocess.STDOUT)
  deadline=time.monotonic()+90;during=None
  while runner.poll() is None and time.monotonic()<deadline:
   during=remote_observation()
   if max(during['files'].values(),default=0)>=20*1024*1024:break
   time.sleep(.2)
  assert during and not during['final_exists'] and max(during['files'].values(),default=0)>=20*1024*1024,during
  write_remote('control/stop',b'qualification interrupted-transfer test\n');stopped=True
  for _ in range(100):
   if json.loads(remote_file('control/status.json'))['shutdown']:break
   time.sleep(.1)
  else:raise RuntimeError('Owned fixture did not stop')
  exit_code=runner.wait(timeout=120);assert exit_code!=0,'Disconnected run reported success'
  interrupted=json.loads((BASE/'installed-peer-fault-interrupted/summary.json').read_text());assert interrupted['status']['state'] in ['finished','failed'],interrupted
  kept=remote_observation();assert not kept['final_exists'],kept
  partials={p:n for p,n in kept['files'].items() if p.startswith('.foldover/partial/')};assert len(partials)==1 and next(iter(partials.values()))>=16*1024*1024,kept
  partial=next(iter(partials));data=remote_file('shared/'+partial);assert data==source.read_bytes()[:len(data)]
 subprocess.run([sys.executable,str(BASE/'restart-peer-fixture.py')],check=True);stopped=False
 deadline=time.monotonic()+180
 while time.monotonic()<deadline:
  p=subprocess.run([CLI,'peers','shares',f['device']],capture_output=True,text=True,timeout=15)
  if p.returncode==0:break
  time.sleep(1)
 else:raise RuntimeError('Peer did not reconnect with retained identity/pins')
 bandwidth('none')
 # The abandoned remote run can retain its normal two-minute lease. Let
 # it expire; never unlink the lease or weaken production fencing.
 print("Waiting 125 seconds for the normal remote lease expiry",flush=True)
 time.sleep(125)
 recovery=preview_apply('installed-peer-fault-retry',a['id'])
 assert hashlib.sha256(remote_file('shared/'+name)).digest()==hashlib.sha256(source.read_bytes()).digest()
 after=remote_observation();assert after['final_exists'] and not after['files'],after
 result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payload_bytes':source.stat().st_size,'staged_bytes_before_disconnect':max(during['files'].values()),'interrupted_run_exit':exit_code,'no_final_target_after_disconnect':True,'retained_partial_bytes':len(data),'partial_matches_source_prefix':True,'reconnected_with_same_identity_and_transport_port':True,'retry_final_hash_matches':True,'partial_removed_after_success':True,'primary_revocation_pending':True,'scope':'Production peer backend on existing-account M1 fixture. No physical network settings changed. Partial retention and successful retry verified; wire bytes reused were not measured.'}
 (BASE/'peer-fault-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
 if runner is not None and runner.poll() is None:
  subprocess.run([CLI,'sync',a['id'],'--cancel'],capture_output=True,text=True,timeout=120);runner.wait(timeout=30)
 bandwidth('none')
