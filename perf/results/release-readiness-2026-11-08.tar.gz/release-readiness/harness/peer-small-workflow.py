"""Run only after ordinary mutual pinning succeeds; never uses the second Mac catalog."""
from peer_support import *
import hashlib,os,plistlib,stat,sys,time
CLI='/Applications/Foldover.app/Contents/Library/LaunchServices/foldover'

def local(args):
 p=subprocess.run([CLI,*args],capture_output=True,text=True,timeout=120);assert p.returncode==0,(args,p.stderr);return p.stdout

def metadata(path):
 def read(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
 return {'data_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'mode':stat.S_IMODE(path.stat().st_mode),'mtime_ns':path.stat().st_mtime_ns,'attributes':{k:''.join(read(['/usr/bin/xattr','-px',k,str(path)]).split()) for k in read(['/usr/bin/xattr',str(path)]).splitlines() if k!='com.apple.provenance'},'acl':read(['/bin/ls','-lde',str(path)]).splitlines()[1:]}

def case(label,pair,*args):
 subprocess.run([sys.executable,str(BASE/'installed-run-case.py'),label,'sync',pair,*args],check=True)
 return json.loads((BASE/label/'summary.json').read_text())['status']

def preview_apply(stem,pair):
 p=case(stem+'-preview',pair,'--preview');assert p['state']=='previewed',p;v=p['preview'];assert v['counts']['conflicts']==v['counts']['blocked']==0,v
 r=case(stem+'-apply',pair,'--approve',str(v['left']['deletions']),str(v['right']['deletions']),'--review',v['review_token']);assert r['state']=='finished' and not r['result']['cancelled'] and r['result']['failure_count']==r['result']['conflicts']==0,r
 return r

if __name__=='__main__':
 l=ledger();f=l['remote_peer_fixture'];peers=json.loads(local(['peers']));assert any(x['device']==f['device'] for x in peers['devices']), 'Normal mutual pinning must complete first'
 shares=json.loads(local(['peers','shares',f['device']]));assert shares['shares']==[{'id':f['share_id'],'name':'Qualification Share'}],shares
 assert not remote_script('/bin/ls -lde '+shlex.quote(f['root']+'/shared')).splitlines()[1:], 'Fixture share unexpectedly inherits ACL rules'
 root=Path(l['fixture_root']);assert (root/'.qualification-owner').read_text().strip()==l['uuid'];left=root/'peer-local';left.mkdir();expected={}
 for i in range(20):
  directory=left/('café' if i%2==0 else 'names-🌱');directory.mkdir(exist_ok=True);name=('café' if i%2==0 else 'cafe\u0301')+f'-{i:02}.dat';p=directory/name;p.write_bytes(hashlib.shake_256(f'foldover-peer-{i}'.encode()).digest(4096));os.chmod(p,0o640)
  if i<2:
   attrs={'org.foldover.qualification':b'peer fixture','com.apple.quarantine':b'0081;6553f100;Foldover;peer-qualification','com.apple.metadata:kMDItemUserTags':plistlib.dumps(['Qualification'],fmt=plistlib.FMT_BINARY)}
   if i==0:
    Path(str(p)+'/..namedfork/rsrc').write_bytes(hashlib.shake_256(b'peer resource fork').digest(65536));subprocess.run(['/bin/chmod','+a','everyone allow readextattr',str(p)],check=True)
   for key,value in attrs.items():subprocess.run(['/usr/bin/xattr','-wx',key,value.hex(),str(p)],check=True)
  os.utime(p,ns=(1700000000123456789,1700000000123456789));expected[str(p.relative_to(left))]=metadata(p)
 write_remote('shared/remote-seed.txt',b'Original second-Mac fixture\n')
 # A pinned device still cannot open an unoffered share.
 import uuid
 bad='peer://'+f['device']+'/'+uuid.uuid4().hex
 p=subprocess.run([CLI,'pairs','add','Qualification refused share',str(left),bad,'sync'],capture_output=True,text=True,timeout=30);
 if p.returncode==0:
  x=ledger();x['owned_pairs']['unexpected-unoffered-share']=json.loads(p.stdout);(BASE/'installed-fixture-private.json').write_text(json.dumps(x,indent=2)+'\n')
 assert p.returncode!=0 and 'not shared' in p.stderr,'Wrong-share request did not produce the expected refusal: '+p.stderr
 (BASE/'peer-unoffered-share-refusal.json').write_text(json.dumps({'returncode':p.returncode,'stderr':p.stderr,'stdout':p.stdout},indent=2)+'\n')
 uri='peer://'+f['device']+'/'+f['share_id'];pair=json.loads(local(['pairs','add','Qualification second Mac',str(left),uri,'sync','--times','sync','--attributes','sync','--permissions','sync','--schedule','manual','--review','required']));l=ledger();l['owned_pairs']['peer-small']=pair;(BASE/'installed-fixture-private.json').write_text(json.dumps(l,indent=2)+'\n');preview_apply('installed-peer-small-initial',pair['id'])
 for rel,original in expected.items():
  assert metadata(left/rel)==original, 'Primary source metadata changed: '+rel
  data=remote_file('shared/'+rel);assert hashlib.sha256(data).hexdigest()==original['data_sha256'],rel
  target=f['root']+'/shared/'+rel
  attrs={k:''.join(remote_script('/usr/bin/xattr -px '+shlex.quote(k)+' '+shlex.quote(target)).split()) for k in original['attributes']};assert attrs==original['attributes'],rel
  mode=int(remote_script('/usr/bin/stat -f %Lp '+shlex.quote(target)).strip(),8);assert mode==original['mode'],(rel,mode)
  mt=int(remote_script(shlex.join(['/usr/bin/python3','-c','import os; print(os.stat('+repr(target)+').st_mtime_ns)'])).strip());assert mt==original['mtime_ns'],(rel,mt)
  acl=remote_script('/bin/ls -lde '+shlex.quote(target)).splitlines()[1:];assert not acl,(rel,acl)
 assert (left/'remote-seed.txt').read_bytes()==b'Original second-Mac fixture\n'
 warm=case('installed-peer-small-warm',pair['id'],'--preview');assert warm['state']=='previewed' and not warm['preview']['items'],warm
 before=metadata(left/'remote-seed.txt');write_remote('shared/remote-seed.txt',b'Changed on the second Mac\n');preview_apply('installed-peer-small-reverse',pair['id']);assert (left/'remote-seed.txt').read_bytes()==b'Changed on the second Mac\n'
 undone=case('installed-peer-small-undo',pair['id'],'--undo');assert undone['state']=='undone' and not undone['result']['cancelled'] and undone['result']['not_undone_count']==0,undone;assert metadata(left/'remote-seed.txt')==before;assert remote_file('shared/remote-seed.txt')==b'Changed on the second Mac\n';preview_apply('installed-peer-small-redo',pair['id'])
 (BASE/'peer-small-verification.json').write_text(json.dumps({'local_generated_files':20,'remote_generated_files':1,'all_primary_source_hashes_and_attributes_match_remote':True,'mode_bits_match':True,'resource_fork_verified':True,'warm_no_change':True,'reverse_change_verified':True,'undo_target_hash_metadata_verified':True,'undo_source_unchanged':True,'unoffered_share_refused':True,'scope':'Production peer backend on M1; stock primary agent/CLI under the launch context recorded separately. Existing M1 app/catalog/Keychain untouched.','remote_nanosecond_mtimes_match':True,'acl_contract':'Peer wire metadata does not carry ACLs. All fresh remote targets had no ACL rules, including the file whose primary source has an explicit ACL. Source ACL was retained; native local ACL copy/undo is separately verified.'},indent=2)+'\n');print('Second-Mac small-file, metadata, reverse sync, scope and undo checks PASS',flush=True)
