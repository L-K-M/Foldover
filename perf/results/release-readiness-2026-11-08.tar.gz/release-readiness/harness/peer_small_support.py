"""Run only after ordinary mutual pinning succeeds; never uses the second Mac catalog."""
from peer_support import *
import hashlib,os,plistlib,stat,sys,time
CLI='/Applications/Foldover.app/Contents/Library/LaunchServices/foldover'

def local(args):
 p=subprocess.run([CLI,*args],capture_output=True,text=True,timeout=120);assert p.returncode==0,(args,p.stderr);return p.stdout

def metadata(path):
 def read(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
 return {'data_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'mode':stat.S_IMODE(path.stat().st_mode),'mtime_ns':path.stat().st_mtime_ns,'attributes':{k:''.join(read(['/usr/bin/xattr','-px',k,str(path)]).split()) for k in read(['/usr/bin/xattr',str(path)]).splitlines() if k!='com.apple.provenance'},'acl':read(['/bin/ls','-lde',str(path)]).splitlines()[1:]}

def case(label,pair,*args):
 subprocess.run([sys.executable,str(BASE/'installed-run-case.py'),label,'sync',pair,*args],check=True)
 return json.loads((BASE/label/'summary.json').read_text())['status']

def preview_apply(stem,pair):
 p=case(stem+'-preview',pair,'--preview');assert p['state']=='previewed',p;v=p['preview'];assert v['counts']['conflicts']==v['counts']['blocked']==0,v
 r=case(stem+'-apply',pair,'--approve',str(v['left']['deletions']),str(v['right']['deletions']),'--review',v['review_token']);assert r['state']=='finished' and not r['result']['cancelled'] and r['result']['failure_count']==r['result']['conflicts']==0,r
 return r

