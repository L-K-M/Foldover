from pathlib import Path
import json,subprocess,shlex
BASE=Path(__file__).resolve().parent

def ledger():return json.loads((BASE/'installed-fixture-private.json').read_text())
def ssh_args():
 c=json.loads((BASE/'peer-connection-private.json').read_text())
 return ['ssh','-T','-i',c['private_key_path'],'-oIdentitiesOnly=yes','-oBatchMode=yes','-oConnectTimeout=10','-oServerAliveInterval=15','-oServerAliveCountMax=4','-oControlMaster=no','-oControlPath=none','-oForwardAgent=no','-oClearAllForwardings=yes','-oStrictHostKeyChecking=yes','-oUserKnownHostsFile='+c['known_hosts_path'],c['target']]
def remote_script(script,timeout=30):
 return subprocess.run([*ssh_args(),'sh','-s'],input=script,capture_output=True,text=True,timeout=timeout,check=True).stdout
def remote_file(relative):
 f=ledger()['remote_peer_fixture'];p=f['root']+'/'+relative
 return subprocess.run([*ssh_args(),'cat',shlex.quote(p)],capture_output=True,timeout=30,check=True).stdout
def write_remote(relative,data,mode='600'):
 f=ledger()['remote_peer_fixture'];root=f['root'];p=root+'/'+relative
 assert relative.startswith(('control/','shared/')) and '..' not in Path(relative).parts
 script='set -eu\n'+f'test "$(cat {shlex.quote(root+"/.qualification-owner")})" = {shlex.quote(f["owner"])}\numask 077\ncat > {shlex.quote(p+".upload")}\nchmod {mode} {shlex.quote(p+".upload")}\nmv {shlex.quote(p+".upload")} {shlex.quote(p)}\n'
 subprocess.run([*ssh_args(),'sh','-c',shlex.quote(script)],input=data,capture_output=True,timeout=60,check=True)
