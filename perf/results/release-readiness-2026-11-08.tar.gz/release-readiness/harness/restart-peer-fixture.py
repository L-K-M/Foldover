"""Keep an authenticated SSH session alive while its foreground fixture runs."""
from peer_support import *
import time,datetime,os
l=ledger();f=l['remote_peer_fixture'];root=f['root'];s=json.loads(remote_file('control/status.json'));assert s['shutdown'];assert s['device']==f['device']
script='set -eu\n'+f'test "$(cat {shlex.quote(root+"/.qualification-owner")})" = {shlex.quote(f["owner"])}\nrm {shlex.quote(root+"/control/stop")}\nulimit -S -n 8192\nprintf "%s\\n" "$$" > '+shlex.quote(root+'/control/server.pid')+'\nexec '+shlex.join([root+'/control/peer_qualification',root,f['owner'],f['expected_primary_device'],f['share_id'],f['lan_ipv4'],'3600'])+'\n'
# Only the local ssh client is detached. The remote command stays in the
# foreground of its live authenticated SSH session until control/stop.
log=BASE/('peer-live-ssh-'+str(time.time_ns())+'-private.log')
with log.open('x') as output:
 connection=subprocess.Popen([*ssh_args(),'sh','-c',shlex.quote(script)],stdin=subprocess.DEVNULL,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
for _ in range(150):
 if connection.poll() is not None:raise RuntimeError('Foreground SSH fixture exited: '+log.read_text())
 s=json.loads(remote_file('control/status.json'))
 if not s['shutdown']:break
 time.sleep(.2)
else:raise RuntimeError('Fixture did not restart')
assert s['device']==f['device'] and s['address']==f['address'];pid=int(remote_file('control/server.pid').strip())
f.update(pid=pid,local_ssh_client_pid=connection.pid,launch_context='Foreground process in a retained authenticated SSH session',pairing_address=s['pairing'],restart_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());l=ledger();l['remote_peer_fixture']=f;(BASE/'installed-fixture-private.json').write_text(json.dumps(l,indent=2)+'\n');print('Fixture restarted with same identity/transport port in a retained foreground SSH session',flush=True)
