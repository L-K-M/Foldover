from peer_support import *
import datetime,hashlib,os,plistlib,re,shutil
l=ledger();rc=json.loads((BASE/'rc/provenance.json').read_text());assert rc['installed_qualification_pending'] is False
archive=BASE/'rc/Foldover-0.2.0-qualification.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()==rc['archive_sha256']
assert l['app_before']=='absent' and l['app_installed_by_qualification'];assert not Path(l['installed_bundle']['path']).exists() and not Path(l['default_catalog']).exists()
s=json.loads((BASE/'sm-unregister-cleanup-private.json').read_text());assert s['returncode']==0;v=json.loads(s['stdout']);assert v['status_raw_value']==0 and v['unregister_error'] is None
mutation=json.loads((BASE/'cleanup-bundle-mutation-private.json').read_text());assert mutation['original_main_sha256']==rc['roles']['app']['sha256']
configuration=json.loads((BASE/'configuration-cleanup-verification.json').read_text());assert configuration['remaining_configuration_exclusively_task_owned'] and configuration['all_remaining_pair_ids_belong_to_task']
labels={l['smservice_label']}|{'ch.lkmc.foldover.agent.'+b['roles']['agent']['cdhash'] for b in l.get('previous_installed_bundles',[])}
for label in labels:
 assert re.fullmatch(r'ch\.lkmc\.foldover\.agent\.[a-f0-9]{40}',label);assert subprocess.run(['launchctl','print',f'gui/{os.getuid()}/'+label],capture_output=True).returncode!=0
assert subprocess.run(['security','find-generic-password','-s','ch.lkmc.foldover.peer-identity','-a','local-device',str(Path.home()/'Library/Keychains/login.keychain-db')],capture_output=True,timeout=15).returncode==44
backup=Path(l['defaults_backup']);assert plistlib.loads(subprocess.check_output(['defaults','export','ch.lkmc.foldover','-']))==plistlib.loads(backup.read_bytes())
root=Path(l['fixture_root']);assert root.parent==Path('/Volumes/PaseoData') and root.name=='foldover-perf-qualification-'+l['uuid'] and not root.is_symlink();assert root.resolve()==root and (root/'.qualification-owner').read_text().strip()==l['uuid']
print('Unregister, installation/catalog removal, own-item deletion, preferences and archive guards verified; deleting only marked local corpora.',flush=True)
shutil.rmtree(root);assert not root.exists()
r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owned_gui_quit':True,'owned_service_unregistered':True,'owned_jobs_absent':True,'own_installation_removed_originally_absent':True,'own_catalog_removed_originally_absent':True,'own_fixture_pin_removed_with_exclusive_task_catalog':True,'public_peer_revocation_qualified':False,'remaining_owned_configuration_removed_with_exclusive_task_catalog':True,'preexisting_defaults_restored':True,'additional_preference_key_removed_after_import':True,'own_new_peer_keychain_item_removed':True,'owned_local_corpora_removed':True,'stock_archive_preserved':True,'scope':'Cleanup-only SMAppService helper was used after sealing/measuring stock bytes, never packaged as the candidate. Normal configuration cleanup returned an error; remaining task-only state was independently audited before deleting the originally absent catalog. defaults import retained one extra key; it was explicitly removed and complete parsed-plist equality verified.'};(BASE/'local-cleanup-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
