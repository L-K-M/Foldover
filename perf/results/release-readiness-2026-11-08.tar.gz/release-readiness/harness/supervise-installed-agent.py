"""Measure the stock installed agent on this session's fresh owned catalog."""
from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,sys,time
w=Path(__file__).resolve().parent
ledger=w/'installed-fixture-private.json'
r=json.loads(ledger.read_text());state=Path(r['default_catalog']);st=state.stat()
assert (st.st_dev,st.st_ino)==(r['catalog_device'],r['catalog_inode'])
assert (state/'.qualification-owner').read_text().strip()==r['uuid']
app=Path(r['installed_bundle']['path']);agent=app/'Contents/Library/LaunchServices/foldoverd';cli=app/'Contents/Library/LaunchServices/foldover'
assert hashlib.sha256(agent.read_bytes()).hexdigest()==r['installed_bundle']['roles']['agent']['sha256']
label=sys.argv[1] if len(sys.argv)>1 else 'installed-agent-session'
assert label.startswith('installed-agent-') and Path(label).name==label
out=w/label;out.mkdir()
summary={'scope':'Stock installed Release app and stock installed agent, normal default catalog and authenticated IPC. Agent launched manually under /usr/bin/time for kernel peak RSS; separate SMAppService lifecycle test required. No state/HOME/source/auth overrides.','revision':r['revision'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'errors':[]}
process=None;agent_pid=None
try:
 with (out/'resources.txt').open('x') as resources,(out/'agent.stdout').open('x') as stdout,(out/'samples.jsonl').open('x') as samples:
  started=time.monotonic();process=subprocess.Popen(['/usr/bin/time','-l',str(agent)],stdout=stdout,stderr=resources,start_new_session=True)
  summary['time_pid']=process.pid
  for _ in range(100):
   rows=subprocess.check_output(['ps','-axo','pid=,ppid=,comm='],text=True)
   for line in rows.splitlines():
    fields=line.strip().split(None,2)
    if len(fields)==3 and int(fields[1])==process.pid and Path(fields[2]).name=='foldoverd':agent_pid=int(fields[0])
   if agent_pid:break
   if process.poll() is not None:raise RuntimeError('Agent exited before startup')
   time.sleep(.1)
  assert agent_pid is not None
  summary['agent_pid']=agent_pid
  (out/'live-private.json').write_text(json.dumps(summary,indent=2)+'\n')
  print('Installed stock agent started under OS timing; PID recorded.',flush=True)
  while process.poll() is None:
   point={'elapsed_seconds':time.monotonic()-started}
   for role,pid in [('agent',agent_pid),('app',r['first_launch_app_pid'])]:
    result=subprocess.run(['ps','-p',str(pid),'-o','rss=,pcpu='],capture_output=True,text=True,timeout=5)
    if result.returncode==0:
     values=result.stdout.split();point[role+'_rss_kib']=int(values[0]);point[role+'_cpu_percent']=float(values[1])
   samples.write(json.dumps(point)+'\n');samples.flush()
   if (out/'STOP').exists():
    os.kill(agent_pid,signal.SIGTERM);break
   time.sleep(1)
  process.wait(timeout=30);summary['returncode']=process.returncode;summary['elapsed_seconds']=time.monotonic()-started
except BaseException as e:
 summary['errors'].append(type(e).__name__+': '+str(e));summary['returncode']=1
 if process is not None and process.poll() is None:
  if agent_pid is not None:
   try:os.kill(agent_pid,signal.SIGTERM)
   except ProcessLookupError:pass
  try:process.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
 raise
finally:
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
