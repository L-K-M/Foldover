from pathlib import Path
import hashlib,json,os,stat,subprocess,time
b=Path(__file__).resolve().parent;l=json.loads((b/'installed-fixture-private.json').read_text());root=Path(l['fixture_root']);assert (root/'.qualification-owner').read_text().strip()==l['uuid'];f=json.loads((b/'deep-metadata-fixture.json').read_text());left=Path(f['left']);right=Path(f['right']);errors=[];files=attrs=acls=forks=0;t=time.monotonic()
def command(args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout
for folder,dirs,names in os.walk(left):
 dirs[:]=[x for x in dirs if x!='.foldover']
 for name in names:
  a=Path(folder)/name;rel=a.relative_to(left);z=right/rel;files+=1
  if not z.is_file():errors.append([str(rel),'missing']);continue
  sa=a.stat();sz=z.stat()
  for key,va,vz in [('sha256',hashlib.sha256(a.read_bytes()).hexdigest(),hashlib.sha256(z.read_bytes()).hexdigest()),('mode',stat.S_IMODE(sa.st_mode),stat.S_IMODE(sz.st_mode)),('mtime_ns',sa.st_mtime_ns,sz.st_mtime_ns)]:
   if va!=vz:errors.append([str(rel),key,va,vz])
  for key in command(['/usr/bin/xattr',str(a)]).splitlines():
   if key=='com.apple.provenance':continue
   attrs+=1;forks+=key=='com.apple.ResourceFork'
   if command(['/usr/bin/xattr','-px',key,str(a)])!=command(['/usr/bin/xattr','-px',key,str(z)]):errors.append([str(rel),'xattr',key])
  aa=command(['/bin/ls','-lde',str(a)]).splitlines()[1:]
  if aa:
   ac=command(['/bin/ls','-lde',str(z)]).splitlines()[1:];acls+=1
   if aa!=ac:errors.append([str(rel),'ACL',aa,ac])
result={'files_verified':files,'attributes_verified':attrs,'resource_forks_verified':forks,'ACL_files_verified':acls,'hash_mode_mtime_checked_each_file':True,'errors':errors,'elapsed_seconds':time.monotonic()-t,'oracle':'Python SHA-256/stat plus system xattr bytes and ls -e ACL text; provenance excluded'};(b/'deep-metadata-independent-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);assert files==1000 and not errors
